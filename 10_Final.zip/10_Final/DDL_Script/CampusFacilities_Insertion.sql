INSERT INTO campusfacilities VALUES(90,'YES','YES','YES',101);
INSERT INTO campusfacilities VALUES(140,'YES','YES','YES',102);
INSERT INTO campusfacilities VALUES(120,'YES','NO','NO',103);
INSERT INTO campusfacilities VALUES(80,'YES','YES','YES',104);
INSERT INTO campusfacilities VALUES(87,'NO','YES','YES',105);


INSERT INTO campusfacilities VALUES(40,'YES','YES','YES',201);
INSERT INTO campusfacilities VALUES(200,'YES','YES','YES',202);
INSERT INTO campusfacilities VALUES(250,'YES','YES','YES',203);
INSERT INTO campusfacilities VALUES(100,'YES','YES','YES',204);
INSERT INTO campusfacilities VALUES(110,'YES','YES','YES',205);
INSERT INTO campusfacilities VALUES(250,'YES','YES','YES',206);
INSERT INTO campusfacilities VALUES(90,'YES','YES','YES',207);
INSERT INTO campusfacilities VALUES(70,'YES','NO','NO',208);
INSERT INTO campusfacilities VALUES(80 ,'NO','NO','YES',209);
INSERT INTO campusfacilities VALUES(50,'YES','NO','NO',210);
