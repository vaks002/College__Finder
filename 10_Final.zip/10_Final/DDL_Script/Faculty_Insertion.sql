//NIT

insert into Faculty Values('MRL11','Mehul Raval',5 ,'Ph.D','CS01',101);
insert into Faculty  Values('MVJ11','M V Joshi' ,8,'MBA','CS02',101 );
insert into Faculty Values('ABJ11','Aseem Benerji',9,'Ph.D','CS04',101);
insert into Faculty Values('PMJ11','P M Jaat',12,'Ph.D','CS03',101);
insert into Faculty Values('VS11','V Sunita',6, 'M.TECH','CS05' ,101);
insert into Faculty Values('SS11','Sanjay Srivastava',11, 'Ph.D','CS06',101);
insert into Faculty  Values('VKC11','Vijay Kumar Chakka',8, 'Ph.D','CS07',101);


insert into Faculty Values('AKV11','ANANDAKRISHNAN V.',13 ,'Ph.D','ME01',101);
insert into Faculty  Values('AG11','ARUNAGIRI.A.' ,8,'MBA','ME03' ,101);
insert into Faculty Values('DLK11','DHANALAKSHMI K',9,'Ph.D','ME02',101);
insert into Faculty Values('DDS11','DEENDAYAL SHARMA',12,'Ph.D','ME04',101);
insert into Faculty Values('GNP11','GOPALAN N.P.',14, 'M.TECH','ME05',101);
insert into Faculty Values('HJ11','HEMALATHA.J.',5, 'Ph.D','ME06',101);
insert into Faculty  Values('IK11','IRFAN KHAN',10, 'MBA','ME07',101);


insert into Faculty Values('DA11','Deepak Atolia ',4 ,'Ph.D','EE01',101);
insert into Faculty  Values('HT11','Hitesh Tilwani' ,7,'MBA','EE03',101 );
insert into Faculty Values('SK11','Sanjay Kumar',6,'Ph.D','EE02',101);
insert into Faculty Values('AV11','Anil Vanjani ',2,'MBA','EE04',101);
insert into Faculty Values('RM11','Rohan Mathur',10, 'M.TECH','EE05',101);
insert into Faculty Values('SBM11','Suraj Bhan Meena',3, 'Ph.D','EE06',101);
insert into Faculty  Values('RVS11','Ravi Kumar Sharma',8, 'MBA','EE07',101);

insert into Faculty Values('HS11',' H.S. SHARMA',3 ,'M.TECH','CE01',101);
insert into Faculty  Values('NK11','N.Kumar' ,8,'MBA','CE03',101 );
insert into Faculty Values('RJS11','R.J. SHARMA',6,'Ph.D','CE02',101);
insert into Faculty Values('PKM11','P.K. MISHRA',11,'Ph.D','CE04',101);
insert into Faculty Values('MSC11','M.S. CHOUHAN',11, 'M.TECH','CE05',101);
insert into Faculty Values('AS11','Ashutosh Sharma',5, 'MBA','CE06',101);
insert into Faculty  Values('AM11','Alok Mittal',7, 'MBA','CE07',101);


insert into Faculty Values('MK11','Manmohan Kapshe ',1 ,'Ph.D','EC01',101);
insert into Faculty  Values('NS11','Namita Srivastava' ,8,'MBA','EC03',101 );
insert into Faculty Values('PKK11','PREMKUMAR K.	',9,'Ph.D','EC02',101);
insert into Faculty Values('MKC11','M.KALICHARAN',12,'MBA','EC04',101);
insert into Faculty Values('PKS11','PREMKUMAR SHARMA',14, 'M.TECH','EC05',101);
insert into Faculty Values('VKS11','VIKRAM SINGH',5, 'Ph.D','EC06',101);
insert into Faculty  Values('PK11','PRADEEP K',10, 'MBA','EC07',101);


insert into Faculty Values('JKN11',' J.K. NARAYANA',7 ,'Ph.D','CHE01',101);
insert into Faculty  Values('GN11','GOVIND NAGAR' ,8,'MBA','CHE02' ,101);
insert into Faculty Values('MLD11','M.L.DAS',9,'Ph.D','CHE03',101);
insert into Faculty Values('RKV11','R.K. VIJAY',12,'MBA','CHE04',101);
insert into Faculty Values('AS11','ANURAG SHARMA',4, 'M.TECH','CHE05',101);
insert into Faculty Values('SG11','SUNIL GOUR',5, 'Ph.D','CHE06',101);
insert into Faculty  Values('RSS11','ROHAN  Srivastava',6, 'Ph.D','CHE07',101);

insert into Faculty Values('SKL11','SAIKALA L ',7 ,'Ph.D','IT01',101);
insert into Faculty  Values('MKD11','MANOJ KUMAR DHAKAR' ,8,'MBA','IT03',101 );
insert into Faculty Values('SNV11','SANKARANARAYANAN V',9,'Ph.D','IT02',101);
insert into Faculty Values('MBM11','MUKUT B MEENA',10,'MBA','IT04',101);
insert into Faculty Values('SRT11','SMITH RAJPUT',5, 'M.TECH','IT05',101);
insert into Faculty Values('VNIK11','VISWANATHAN IYER K',12, 'Ph.D','IT06',101);
insert into Faculty  Values('WFR11','WILSON FREDERICK',13, 'Ph.D','IT07',101);








insert into Faculty Values('VK12','VIKRAM MEENA',5 ,'Ph.D','CS11',102);
insert into Faculty  Values('RD12','ROHAN DHOOT' ,8,'MBA','CS12',102 );
insert into Faculty Values('AB12','Aseem sharma',9,'Ph.D','CS14',102);
insert into Faculty Values('PM12','P M Jaat',12,'Ph.D','CS13',102);
insert into Faculty Values('VSS12','V Sunita Sharma',6, 'M.TECH','CS15' ,102);
insert into Faculty Values('SV12','Sanjay Venka',11, 'Ph.D','CS16',102);
insert into Faculty  Values('VK12','Vijay Kumar ',8, 'Ph.D','CS17',102);


insert into Faculty Values('AN12','ANANDA V.',14 ,'Ph.D','ME11',102);
insert into Faculty  Values('AGS12','ARUNAGIRI SHARMA' ,7,'MBA','ME13' ,102);
insert into Faculty Values('DLK12','DHANALAKSHMI K',10,'Ph.D','ME12',102);
insert into Faculty Values('DD12','DEENDAYAL DHOOT',11,'Ph.D','ME14',102);
insert into Faculty Values('GNP12','GOPALAN  PRAKASH',13, 'M.TECH','ME15',102);
insert into Faculty Values('HJ12','HEMALATHA.J.',6, 'Ph.D','ME16',102);
insert into Faculty  Values('IK12','IRFAN KUMAR',9, 'MBA','ME17',102);


insert into Faculty Values('DH12','Deepak Hooda ',4 ,'Ph.D','EE11',102);
insert into Faculty  Values('HD12','Hitesh dixit' ,7,'MBA','EE13',102);
insert into Faculty Values('SK12','Sanjeev Kumar',6,'Ph.D','EE12',102);
insert into Faculty Values('AV12',' Avakaran Vansh ',2,'MBA','EE14',102);
insert into Faculty Values('RM12','Rohan Mathur',10, 'M.TECH','EE15',102);
insert into Faculty Values('SBM12','Suraj Bhan Meena',3, 'Ph.D','EE16',102);
insert into Faculty  Values('RJ12','Rajat Sharma',8, 'MBA','EE17',102);

insert into Faculty Values('HS12',' H.SAI',3 ,'M.TECH','CE11',102);
insert into Faculty  Values('NK12','N.KAMLESH' ,8,'MBA','CE13',102 );
insert into Faculty Values('RJS','R.J. SHARMA',6,'Ph.D','CE12',102);
insert into Faculty Values('PKM12','P.K. MISHRA',11,'Ph.D','CE14',102);
insert into Faculty Values('MSC12','M.S. CHOUHAN',11, 'M.TECH','CE15',102);
insert into Faculty Values('AS12','Ashutosh Sharma',5, 'MBA','CE16',102);
insert into Faculty  Values('AM12','Alok Mishra',7, 'MBA','CE17',102);


insert into Faculty Values('MK12','MADHAV KHANDELWAL',1 ,'Ph.D','EC11',102);
insert into Faculty  Values('NS12','Namita SHARMA' ,8,'MBA','EC13',102 );
insert into Faculty Values('PK12','PRAKASH K.	',9,'Ph.D','EC12',102);
insert into Faculty Values('VM12','VIKAS MUNDRA',12,'MBA','EC14',102);
insert into Faculty Values('PKS12','PREMKUMAR SHARMA',14, 'M.TECH','EC15',102);
insert into Faculty Values('VKS12','VIKRAM SINGH',5, 'Ph.D','EC16',102);
insert into Faculty  Values('PK12','PRADEEP K',10, 'M.TECH','EC17',102);


insert into Faculty Values('JB12',  ' JIGNESH BHATT',7 ,'Ph.D','CHE11',102);
insert into Faculty  Values('G12','GOVINDA N' ,8,'MBA','CHE12' ,102);
insert into Faculty Values('MKV12','MADHAV V',9,'Ph.D','CHE13',102);
insert into Faculty Values('RKV12','R.K. VANJAINI',12,'MBA','CHE14',102);
insert into Faculty Values('AS12','ASHISH SHARMA',4, 'M.TECH','CHE15',102);
insert into Faculty Values('SG12','SANKALP GOUR',5, 'M.TECH','CHE16',102);
insert into Faculty  Values('SV12','SHANKAR VIJAY',6, 'MBA','CHE17',102);

insert into Faculty Values('SKL12','SHARAD KUMAR ',7 ,'Ph.D','IT11',102);
insert into Faculty  Values('MKD12','MANOJ VAJPAYEE' ,8,'MBA','IT13',102 );
insert into Faculty Values('SNV12','SANYA V',9,'Ph.D','IT12',102);
insert into Faculty Values('MM12','MUKUT MAHESHWARI',10,'MBA','IT14',102);
insert into Faculty Values('SCR12','SMITH CHRISTIAN',5, 'M.TECH','IT15',102);
insert into Faculty Values('VK12','VIVEK  KUMAR',12, 'M.TECH','IT16',102);
insert into Faculty  Values('WFR12','WILSON FREDERICK',11, 'MBA','IT17',102);












insert into Faculty values('YJ13','YOGENDER JANGIR',11,'M.TECH','CS21',103);
insert into Faculty values('RJ13','RADHESHYAM JANGID',10,'MBA','CS22',103);
insert into Faculty values('PD13','PRAKHAR DHOOT',4,'PHD','CS23',103);
insert into Faculty values('KS13','KAPIL SHARMA',5,'M.TECH','CS24',103);
insert into Faculty values('VB13','VARUN BAFNA',7,'M.TECH','CS25',103);
insert into Faculty values('RDJ13','RAVINDRA JADEJA',6,'MBA','CS26',103);
insert into Faculty values('TN13','T.NATRAJAN',6,'M.TECH','CS27',103);


insert into Faculty values('SK13','SHAHRUKH KHAN',10,'M.TECH','EE21',103);
insert into Faculty values('KD13','KAUSTUBH DWIVEDI',7,'MBA','EE22',103);
insert into Faculty values('YN13','YOGENDER JAIN',6,'M.TECH','EE23',103);
insert into Faculty values('HJ13','HARSHAL JHANWAR',8,'PH,d','EE24',103);
insert into Faculty values('AN13','ABHISHEK NAGAR',13,'MBA','EE25',103);
insert into Faculty values('NJ13','NAMAN JHANWAR',5,'M.TECH','EE26',103);
insert into Faculty values('KH13','KUMAR HIMANSHU',9,'M.S','EE27',103);


insert into Faculty values('SS13','SANDEEP SANKESARA',10,'M.TECH','EC21',103);
insert into Faculty values('KR13','KAUSTUBH KAPOOR',7,'MBA','EC22',103);
insert into Faculty values('YDJ13','YOGENDER JANGIR',6,'M.TECH','EC23',103);
insert into Faculty values('NAJ13','NAVEEN JHANWAR',8,'PH,d','EC24',103);
insert into Faculty values('ABY13','ABHIYUDAY NAGAR',13,'MBA','EC25',103);
insert into Faculty values('GJ13','GAGAN JHANWAR',5,'M.TECH','EC26',103);
insert into Faculty values('HK13',' HIMANSHU KUMAR',9,'M.S','EC27',103);







insert into Faculty values('SD13','SANDY DIMITRI',10,'M.TECH','IT21',103);
insert into Faculty values('KKD13','KAUSTUBH KUMAR DWIVEDI',7,'MBA','IT22',103);
insert into Faculty values('FJ13','FARAN  JANGIR',6,'M.TECH','IT23',103);
insert into Faculty values('BJ13','BABU JHANWAR',8,'PH,d','IT24',103);
insert into Faculty values('BN13','BHARGAV NAGAR',13,'MBA','IT25',103);
insert into Faculty values('SJ13','SUMAN JHANWAR',5,'M.TECH','IT26',103);
insert into Faculty values('RK13',' RISHABH KUMAR',9,'M.S','IT27',103);



insert into Faculty values('KUY13','KULDEEP YADAV',10,'M.TECH','CHE21',103);
insert into Faculty values('KUS13','KUSH SINGH',7,'MBA','CHE22',103);
insert into Faculty values('NAJ13','NAMAZ  JANGIR',6,'M.TECH','CHE23',103);
insert into Faculty values('BLJ13','BABULAL JHANWAR',8,'PH,d','CHE24',103);
insert into Faculty values('BAN13','BASMATI NAGAR',13,'MBA','CHE25',103);
insert into Faculty values('SUS13','SUMAN  SINGH ',5,'M.TECH','CHE26',103);
insert into Faculty values('HB13',' HARASHA BHOGLE',9,'M.S','CHE27',103);





	insert into Faculty values('POS13','POOJA SINGH',10,'M.TECH','ME21',103);
insert into Faculty values('MOD13','MONIKA DURGA',7,'MBA','ME22',103);
insert into Faculty values('SHS13','SHIKHA SACHAN',6,'M.TECH','ME23',103);
insert into Faculty values('SAS13','SHALU SENGAR',8,'PH,d','ME24',103);
insert into Faculty values('SDY13','SANDYA YADAV',13,'MBA','ME25',103);
insert into Faculty values('SY13','SUMAN YADAV',5,'M.TECH','ME26',103);
insert into Faculty values('DP13',' DISHA PATANI',9,'M.S','ME27',103);




insert into Faculty values('RED13','REKHA DEVI',10,'M.TECH','CE21',103);
insert into Faculty values('MKD13','MONIKA KUMARI DURGA',7,'MBA','CE22',103);
insert into Faculty values('BAC13','BARNALI CHETIA',6,'M.TECH','CE23',103);
insert into Faculty values('AAP13','ASHISH PHOPHALIA',8,'PH,d','CE24',103);
insert into Faculty values('HES13','HEET SANKESARA',13,'MBA','CE25',103);
insert into Faculty values('PAS13','PARUL SHAH',5,'M.TECH','CE26',103);
insert into Faculty values('DIP13',' DIPIKA PADUKONE',9,'M.S','CE27',103);

insert into Faculty values('YJ14','YOGENDER JANGIR',11,'M.TECH','CS31',104);
insert into Faculty values('RJ14','RADHESHYAM JANGID',10,'MBA','CS32',104);
insert into Faculty values('PD14','PRAKHAR DHOOT',4,'PHD','CS33',104);
insert into Faculty values('KS14','KAPIL SHARMA',5,'M.TECH','CS34',104);
insert into Faculty values('VBF14','VARUN BAFNA',7,'M.TECH','CS35',104);
insert into Faculty values('RDJ14','RAVINDRA JADEJA',6,'MBA','CS36',104);
insert into Faculty values('TN14','T.NATRAJAN',6,'M.TECH','CS37',104);





insert into Faculty values('SK14','SHAHRUKH KHAN',10,'M.TECH','EE31',104);
insert into Faculty values('KD14','KAUSTUBH DWIVEDI',7,'MBA','EE32',104);
insert into Faculty values('YN14','YOGENDER JAIN',6,'M.TECH','EE33',104);
insert into Faculty values('HJ14','HARSHAL JHANWAR',8,'PH,d','EE34',104);
insert into Faculty values('AKN14','ABHISHEK KUMAR NAGAR',14,'MBA','EE35',104);
insert into Faculty values('SKJ14','SANKALP KUMAR JHANWAR',5,'M.TECH','EE36',104);
insert into Faculty values('KH14','KUMAR HIMANSHU',9,'M.S','EE37',104);





insert into Faculty values('SS14','SANDEEP SANKESARA',10,'M.TECH','EC31',104);
insert into Faculty values('KR14','KAUSTUBH KAPOOR',7,'MBA','EC32',104);
insert into Faculty values('YDJ14','YOGENDER JANGIR',6,'M.TECH','EC33',104);
insert into Faculty values('NAJ14','NAVEEN JHANWAR',8,'PH,d','EC34',104);
insert into Faculty values('ABYN14','ABHIYUDAY NAGAR',14,'MBA','EC35',104);
insert into Faculty values('GKJ14','GAGAN KUMAR JHANWAR',5,'M.TECH','EC36',104);
insert into Faculty values('HKT14',' HIMANSHU KUMAR THAKOR',9,'M.S','EC37',104);







insert into Faculty values('SD14','SANDY DIMITRI',10,'M.TECH','IT31',104);
insert into Faculty values('KKD14','KAUSTUBH KUMAR DWIVEDI',7,'MBA','IT32',104);
insert into Faculty values('FJ14','FARAN  JANGIR',6,'M.TECH','IT33',104);
insert into Faculty values('BJ14','BABU JHANWAR',8,'PH,d','IT34',104);
insert into Faculty values('GN14','GOUTAM NAGAR',14,'MBA','IT35',104);
insert into Faculty values('SJ14','SUMAN JHANWAR',5,'M.TECH','IT36',104);
insert into Faculty values('RKC14',' RISHABH KUMAR CHOUHAN',9,'M.S','IT37',104);


insert into Faculty values('KUY14','KULDEEP YADAV',10,'M.TECH','CHE31',104);
insert into Faculty values('KUN14','KUSHI NAGAR',7,'MBA','CHE32',104);
insert into Faculty values('VKB14',' VARNIKA BAFNA',6,'M.TECH','CHE33',104);
insert into Faculty values('BLJ14','BABULAL JHANWAR',8,'PH,d','CHE34',104);
insert into Faculty values('BAN14','BASMATI NAGAR',13,'MBA','CHE35',104);
insert into Faculty values('SVS14','SUMAN  VASHISHTH ',5,'M.TECH','CHE36',104);
insert into Faculty values('HB14',' HARASHA BHOGLE',9,'M.S','CHE37',104);



insert into Faculty values('HRS14','HARSHITA SINGH',10,'M.TECH','ME31',104);
insert into Faculty values('HRD14','HARSHITA DURGA',7,'MBA','ME32',104);
insert into Faculty values('VNS14','VARNIKA SACHAN',6,'M.TECH','ME33',104);
insert into Faculty values('SAD14','SHALU DWIVEDI',8,'PH,d','ME34',104);
insert into Faculty values('SDY14','SANDYA YADAV',14,'MBA','ME35',104);
insert into Faculty values('AY14','AMAN YADAV',5,'M.TECH','ME36',104);
insert into Faculty values('AD14',' AMAN DHOOT',9,'M.S','ME37',104);




insert into Faculty values('REDJ14','REKHA DEVI BAJAJ',10,'M.TECH','CE31',104);
insert into Faculty values('MD14','MONIKA DURGA',7,'MBA','CE32',104);
insert into Faculty values('BAC14','BARNALI CHETIA',6,'M.TECH','CE33',104);
insert into Faculty values('AS14','AARZOO SHARMA',8,'PH,d','CE34',104);
insert into Faculty values('MY14','MOHIT YADAV',14,'MBA','CE35',104);
insert into Faculty values('PA14','PARUL JANGIR',5,'M.TECH','CE36',104);
insert into Faculty values('DIN14',' DIPIKA NAGAR',9,'M.S','CE37',104);

insert into Faculty values('RLJ15','RAMLAL JANGIR',11,'M.TECH','CS41',105);
insert into Faculty values('RJ15','RADHESHYAM JANGID',10,'MBA','CS42',105);
insert into Faculty values('CD15','CHAMAN DHOOT',4,'PHD','CS43',105);
insert into Faculty values('KS15','KAPIL SHARMA',5,'M.TECH','CS44',105);
insert into Faculty values('VKL15','VARUN KOHLI',7,'M.TECH','CS45',105);
insert into Faculty values('RDJ15','RAVINDRA JADEJA',6,'MBA','CS46',105);
insert into Faculty values('TN15','T.NATRAJAN',6,'M.TECH','CS47',105);




insert into Faculty values('SK15','SHAHRUKH KHAN',10,'M.TECH','EE41',105);
insert into Faculty values('KD15','KAUSTUBH DWIVEDI',7,'MBA','EE42',105);
insert into Faculty values('YN15','YOGENDER JAIN',6,'M.TECH','EE43',105);
insert into Faculty values('HJ15','HARSHAL JHANWAR',8,'PH,d','EE44',105);
insert into Faculty values('AKN15','ABHISHEK KUMAR NAGAR',15,'MBA','EE45',105);
insert into Faculty values('SKJ15','SANKALP KUMAR JHANWAR',5,'M.TECH','EE46',105);
insert into Faculty values('KH15','KUMAR HIMANSHU',9,'M.S','EE47',105);






insert into Faculty values('SS15','SANKALP SHARMA',10,'M.TECH','EC41',105);
insert into Faculty values('KPR15','KAUSTUBH KAPOOR',7,'MBA','EC42',105);
insert into Faculty values('YJ15','YOGENDER JANGIR',6,'M.TECH','EC43',105);
insert into Faculty values('NAJ15','NAVEEN JHANWAR',8,'PH,d','EC44',105);
insert into Faculty values('ABYN15','ABHIYUDAY NAGAR',15,'MBA','EC45',105);
insert into Faculty values('CKJ15','CHAMAN KUMAR JHANWAR',5,'M.TECH','EC46',105);
insert into Faculty values('KT15',' KUNAL THAKOR',9,'M.S','EC47',105);





insert into Faculty values('NR15','NIKHIL RATHI',10,'M.TECH','IT41',105);
insert into Faculty values('KKD15','KAUSTUBH KUMAR DWIVEDI',7,'MBA','IT42',105);
insert into Faculty values('BTK15',' BHAVESH THAOKR',6,'M.TECH','IT43',105);
insert into Faculty values('BJ15','BABU JHANWAR',8,'PH,d','IT44',105);
insert into Faculty values('VN15','VISHNU NAGAR',15,'MBA','IT45',105);
insert into Faculty values('SJ15','SUMAN JHANWAR',5,'M.TECH','IT46',105);
insert into Faculty values('RKC15',' ROHAN KUMAR CHOUHAN',9,'M.S','IT47',105);





insert into Faculty values('KKY15','KULDEEP KUMAR YADAV',10,'M.TECH','CHE41',105);
insert into Faculty values('DRAJ15','DIKSHA RAJORA',7,'MBA','CHE42',105);
insert into Faculty values('VKB15',' VARNIKA BAFNA',6,'M.TECH','CHE43',105);
insert into Faculty values('JYTM15','JYOTI MEENA',8,'PH,d','CHE44',105);
insert into Faculty values('VNM15','VAISHANAVI MER',13,'MBA','CHE45',105);
insert into Faculty values('SVS15','SUMAN  VASHISHTH ',5,'M.TECH','CHE46',105);
insert into Faculty values('HB15',' HARASHA BHOGLE',9,'M.S','CHE47',105);







insert into Faculty values('HRS15','HARSHITA SINGH',10,'M.TECH','ME41',105);
insert into Faculty values('VND15','VARNIKA DURGA',7,'MBA','ME42',105);
insert into Faculty values('HRSMS15','HARSHITA MEENA',6,'M.TECH','ME43',105);
insert into Faculty values('SAD15','SHALU DWIVEDI',8,'PH,d','ME44',105);
insert into Faculty values('SDY15','SANDYA YADAV',15,'MBA','ME45',105);
insert into Faculty values('AY15','AMAN YADAV',5,'M.TECH','ME46',105);
insert into Faculty values('AD15',' AMAN DHOOT',9,'M.S','ME47',105);




insert into Faculty values('REDJ15','REKHA DEVI BAJAJ',10,'M.TECH','CE41',105);
insert into Faculty values('MD15','MONIKA DURGA',7,'MBA','CE42',105);
insert into Faculty values('BAC15','BARNALI CHETIA',6,'M.TECH','CE43',105);
insert into Faculty values('AS15','AARZOO SHARMA',8,'PH,d','CE44',105);
insert into Faculty values('MY15','MOHIT YADAV',15,'MBA','CE45',105);
insert into Faculty values('PA15','PARUL JANGIR',5,'M.TECH','CE46',105);
insert into Faculty values('DIN15',' DIPIKA NAGAR',9,'M.S','CE47',105);


//IIIT

insert into Faculty Values('ZK21','Zahid kurasi',5 ,'Ph.D','CS101',201);
insert into Faculty  Values('MLD21','Manik lal Das' ,10,'MBA','CS102',201 );
insert into Faculty Values('KLS21','kailash singh',9,'Ph.D','CS103',201);
insert into Faculty Values('DIK21','Dilip kumar',11,'Ph.D','CS103',201);
insert into Faculty Values('VS21','Vanita sachan',6, 'M.TECH','CS105',201);
insert into Faculty Values('SSS21','Sanjay Singh Singhania',11, 'Ph.D','CS106',201);
insert into Faculty  Values('VS21','Vinit singh',8, 'Ph.D','CS107',201);



insert into Faculty Values('SRJ21','Smit Rajput',13 ,'Ph.D','IT101',201);
insert into Faculty  Values('SKR21','Shubham Singh' ,8,'MBA','IT102',201 );
insert into Faculty Values('SRS21','Srikant singh',9,'Ph.D','IT103',201);
insert into Faculty Values('DKS21','Direndra singh',12,'Ph.D','IT104',201);
insert into Faculty Values('GS21','Girish Singh',14, 'M.TECH','IT105',201);
insert into Faculty Values('CCS21','chanchal singh',5, 'Ph.D','IT106',201);
insert into Faculty  Values('AA21','Atif Aslam',10, 'MBA','IT107',201);





insert into Faculty Values('DS22','Dilip Singh ',4 ,'Ph.D','CS111',202);
insert into Faculty  Values('HMT22','Hemant tiwari' ,7,'MBA','CS112',202 );
insert into Faculty Values('JA22','Jitu Awasthi',6,'Ph.D','CS113',202);
insert into Faculty Values('AB22','Anil Bajpai ',2,'MBA','CS114',202);
insert into Faculty Values('RS22','Rohan Singh',10, 'M.TECH','CS115',202);
insert into Faculty Values('SM22','Suraj Meena',3, 'Ph.D','CS116',202);
insert into Faculty  Values('RK22','Ravi Kumar',8, 'MBA','CS117',202);



insert into Faculty Values('HS22',' Kunal. SHARMA',3 ,'M.TECH','IT111',202);
insert into Faculty  Values('NIK22','Nilesh Kumar' ,8,'MBA','IT112',202 );
insert into Faculty Values('RJR22','Ranjana rajput',6,'Ph.D','IT113',202);
insert into Faculty Values('PKP22','P.K panday',11,'Ph.D','IT114',202);
insert into Faculty Values('MSD22','M.S Dhoni',11, 'M.TECH','IT115',202);
insert into Faculty Values('AK22','Ashutosh Kushwaha',5, 'MBA','IT116',202);
insert into Faculty  Values('AMS22','Anup Maheswari',7, 'MBA','IT116',202);




insert into Faculty Values('MK23','Manmohan Kumar ',10 ,'Ph.D','CS121',203);
insert into Faculty  Values('NS23','Namita Sachan' ,8,'MBA','CS122',203 );
insert into Faculty Values('PKK23','PREMKUMAR K.	',9,'Ph.D','CS123',203);
insert into Faculty Values('MKC23','M.Koul',12,'MBA','CS124',203);
insert into Faculty Values('PSS23','Pradeep SHARMA',14, 'M.TECH','CS125',203);
insert into Faculty Values('VMS23','VIKRAM Meena',15, 'Ph.D','CS126');
insert into Faculty  Values('PK23','PRADEEP K',10, 'MBA','CS127',203);



insert into Faculty Values('JK23',' J.KUMAR ',17 ,'Ph.D','IT121',203);
insert into Faculty  Values('GNU23','GOVIND NAGAR UPADHAY' ,8,'MBA','IT122',203 );
insert into Faculty Values('MLP23','M.L.PRASAD',2,'Ph.D','IT123',203);
insert into Faculty Values('RKJ23','R.K. JHA',12,'MBA','IT124',203);
insert into Faculty Values('AK23','ANURUDDHA KUMAR',4, 'M.TECH','IT125',203);
insert into Faculty Values('SG23','SANKALP GOUR',5, 'Ph.D','ITE126',203);
insert into Faculty  Values('RSS23','ROHAN SACHAN',6, 'Ph.D','ITE127',203);




insert into Faculty Values('SKL24','SAIKALA L ',7 ,'Ph.D','CS131',204);
insert into Faculty  Values('MKD24','MANISH KUMAR DHAKAR' ,8,'MBA','CS132',204 );
insert into Faculty Values('SNV24','SAROJ V',9,'Ph.D','CS133',204);
insert into Faculty Values('MBM24','MUKUT C MEENA',10,'MBA','CS134',204);
insert into Faculty Values('SRT24','SMITH RAJPUT',5, 'M.TECH','CS0135',204);
insert into Faculty Values('VIK24','VISWANATHAN IYER K',12, 'Ph.D','CS136',204);
insert into Faculty  Values('WIF24','WILLIUM FREDERICK',12, 'Ph.D','CS137',204);



insert into Faculty Values('KD24','KAUSTUBH DWIVEDI',7 ,'Ph.D','IT131',204);
insert into Faculty  Values('MD24','MANISH DUBEY' ,8,'MBA','IT132',204 );
insert into Faculty Values('HD24','HARSH DWIVEDI',9,'Ph.D','IT133',204);
insert into Faculty Values('SJM24','SHYAM JI ',10,'MBA','IT134',204);
insert into Faculty Values('DK24','DINESH KUMAR',5, 'M.TECH','IT135',204);
insert into Faculty Values('VM24','VIKAS MISHRA',12, 'Ph.D','IT136',204);
insert into Faculty  Values('AS24','ANDREW SIMONS',12, 'Ph.D','IT137',204);



insert into Faculty Values('SG25','SANKALP GOUR',7 ,'Ph.D','CS141',205);
insert into Faculty  Values('MM25','MIKESH MISHRA' ,8,'MBA','CS142',205 );
insert into Faculty Values('LL25','LINDA LAKRI',9,'Ph.D','CS143',205);
insert into Faculty Values('KS25',' KAPIL SAMBA ',10,'MBA','CS144',205);
insert into Faculty Values('MM25','MEHUL MISHRA',5, 'M.TECH','CS145',205);
insert into Faculty Values('VK25','VIKAS KASYAP',12, 'BCA','CS146',205);
insert into Faculty  Values('DD25','DAVID DHAVAN',12, 'Ph.D','CS147',205);





insert into Faculty Values('YY25','YOGI YADAV ',7 ,'Ph.D','IT141',205);
insert into Faculty  Values('DM25','DISHA MISHRA' ,8,'MBA','IT142',205 );
insert into Faculty Values('KC25','KAPIL CHOUDHARY',9,'Ph.D','IT143',205);
insert into Faculty Values('SS25',' SUDHA SAMBA ',10,'MBA','IT144',205);
insert into Faculty Values('PM25','PRIYA MISHRA',5, 'M.TECH','IT145',205);
insert into Faculty Values('MK25','MALIK KHAN',12, 'Ph.D','IT146',205);
insert into Faculty  Values('DK25','DAVID KUMAR',12, 'Ph.D','IT147',205);




insert into Faculty Values('HY26','HARSHA YADAV ',7 ,'Ph.D','CS151',206);
insert into Faculty  Values('KM26','KRITIKA MISHRA' ,8,'MBA','CS152',206 );
insert into Faculty Values('KC26','KUNAL CHOUDHARY',9,'Ph.D','CS153',206);
insert into Faculty Values('SS26',' SAVITA SAMBA ',10,'MBA','CS154',206);
insert into Faculty Values('DM26','DILIP MISHRA',5, 'M.TECH','CS155',206);
insert into Faculty Values('MK26','MOHAMAD KAIF',12, 'Ph.D','CS156',206);
insert into Faculty  Values('ABD26','A.B.DIVILIARS',12, 'MBA','CS157',206);






insert into Faculty Values('AY25','AMAN YADAV ',7 ,'Ph.D','IT151',206);
insert into Faculty  Values('EM25','EKTA MISHRA' ,8,'MBA','IT152',206 );
insert into Faculty Values('JD26','JAGDISH DWIVEDI',9,'Ph.D','IT153',206);
insert into Faculty Values('KD25',' KUSUM DWIVEDI ',10,'MBA','IT154',206);
insert into Faculty Values('DD25',' DIVYA DWIVEDI',5, 'M.TECH','IT155',206);
insert into Faculty Values('ZK25','ZIAUL KHAN',12, 'Ph.D','IT156',206);
insert into Faculty  Values('DM25','DAVID MILLAR',17, 'Ph.D','IT0157',206);









insert into Faculty Values('LS27','LALIT SINGH ',7 ,'Ph.D','CS161',207);
insert into Faculty  Values('FS27','FATIMA SEKH' ,8,'MBA','CS162',207 );
insert into Faculty Values('GN27','GNANA NIVAS',9,'Ph.D','CS163',207);
insert into Faculty Values('JS27',' JIHAD SEKH ',10,'MBA','CS164',207);
insert into Faculty Values('BM27','BHIM MISHRA',5, 'M.TECH','CS165',207);
insert into Faculty Values('LK27','LALIT KAIF',12, 'Ph.D','CS166',207);
insert into Faculty  Values('VK27','VIRAT KOHLI',12, 'Ph.D','CS167',207);





insert into Faculty Values('AK27',' AMIR KHAN',7 ,'Ph.D','IT161',207);
insert into Faculty  Values('HA27','HARSH AWASTHI' ,8,'MBA','IT162',207 );
insert into Faculty Values('SS27','SUNNY SANKESARA',9,'Ph.D','IT163',207);
insert into Faculty Values('JD27',' JONNY DHOOT ',10,'MBA','IT164',207);
insert into Faculty Values('KY27','KRISNA YADAV',5, 'M.TECH','IT165',207);
insert into Faculty Values('GK27','GABRU KAIF',12, 'Ph.D','IT166',207);
insert into Faculty  Values('RP27','RICKT PONTING',12, 'Ph.D','IT167',207);




insert into Faculty Values('DY28','DINESH YADAV ',7 ,'Ph.D','CS171',208);
insert into Faculty  Values('JA28',' JONNY ANDREWS' ,8,'MBA','CS172',208 );
insert into Faculty Values('KC28','KAPIL DEV',9,'Ph.D','CS173',208);
insert into Faculty Values('DS28',' DEVI SRI ',10,'MBA','CS174',208);
insert into Faculty Values('GT28','GARIMA TIWARI',5, 'M.TECH','CS175',208);
insert into Faculty Values('MD28','MAHIMA DEVI',12, 'Ph.D','CS176',208);
insert into Faculty  Values('JDD28','JEETU DUBEY',12, 'Ph.D','CS177',208);




insert into Faculty Values('AK28',' AADIL KHAN',7 ,'Ph.D','IT171',208);
insert into Faculty  Values('HA28','HIMESH AWASTHI' ,8,'MBA','IT172',208 );
insert into Faculty Values('SS28','SUNIL SANKESARA',9,'Ph.D','IT173',208);
insert into Faculty Values('JD28',' JEETU DHOOT ',10,'MBA','IT174',208);
insert into Faculty Values('KY28','KEDAR YADAV',5, 'M.TECH','IT175',208);
insert into Faculty Values('GK28','GEYAN KAIF',12, 'Ph.D','IT176',208);
insert into Faculty  Values('SN28','SUNIL NARAIN',12, 'Ph.D','IT177',208);





insert into Faculty Values('HPY29','HARI PRASAD YADAV ',7 ,'Ph.D','CS181',209);
insert into Faculty  Values('MF29',' M.FARAN ' ,8,'MBA','CS182',209 );
insert into Faculty Values('HK29','HUSSIAN KHAN',9,'Ph.D','CS183',209);
insert into Faculty Values('IS29',' INNAYA SINGH ',10,'MBA','CS184',209);
insert into Faculty Values('LS29','LALITA SEKH',5, 'M.TECH','CS185',209);
insert into Faculty Values('MD29','MAHIMA DUBEY',12, 'Ph.D','CS186',209);
insert into Faculty  Values('JDD29','JOHN DUBEY',12, 'Ph.D','CS187',209);




insert into Faculty Values('AK29',' ANAS KHAN',7 ,'Ph.D','IT181',209);
insert into Faculty  Values('HA29','HARDIK AWASTHI' ,8,'MBA','IT182',209 );
insert into Faculty Values('SS29','SHOBHIT SANKESARA',9,'Ph.D','IT183',209);
insert into Faculty Values('JD29',' JACOB DHOOT ',10,'MBA','IT184',209);
insert into Faculty Values('KY29','KESAV YADAV',5, 'M.TECH','IT185',209);
insert into Faculty Values('NY29','NOBITA YOHANA',12, 'Ph.D','IT186',209);
insert into Faculty  Values('SSN29','SUSHIL S.N',12, 'Ph.D','IT187',209);


insert into Faculty Values('HY20','DINESH YADAV ',7 ,'Ph.D','CS191',210);
insert into Faculty  Values('KS20',' KARAN SINGH' ,8,'MBA','CS192',210 );
insert into Faculty Values('KC20','KAPIL DWIVEDI',9,'Ph.D','CS193',210);
insert into Faculty Values('DS20',' DEVI SRIVASTAV ',10,'MBA','CS194',210);
insert into Faculty Values('GT20','GANESH TIWARI',5, 'M.TECH','CS195',210);
insert into Faculty Values('MD20','MAHIMA DUBAY',12, 'Ph.D','CS196',210);
insert into Faculty  Values('JS20','JACOB SMITH',12, 'Ph.D','CS197',210);




insert into Faculty Values('SK20',' SALMAN KHAN',7 ,'Ph.D','IT191',210);
insert into Faculty  Values('HH20','HIMESH HITKOSHI' ,8,'MBA','IT192',210 );
insert into Faculty Values('SS20','SHASHANK SANKESARA',9,'Ph.D','IT193',210);
insert into Faculty Values('RD20',' ROHAN DHOOT ',10,'MBA','IT194',210);
insert into Faculty Values('KY20','KUNAL YADAV',5, 'M.TECH','IT195',210);
insert into Faculty Values('GS20','GIRISH SINGH',12, 'Ph.D','IT196',210);
insert into Faculty  Values('ST20','SUNIL TIWARI',12, 'Ph.D','IT197',210);
