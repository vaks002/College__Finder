Insert into offers values(101,'101_CSE');
Insert into offers values(101,'101_ME');
Insert into offers values(101,'101_EE');
Insert into offers values(101,'101_ECE');
Insert into offers values(101,'101_CE');
Insert into offers values(101,'101_CHE');
Insert into offers values(101,'101_IT');

Insert into offers values(102,'102_CSE');
Insert into offers values(102,'102_EE');
Insert into offers values(102,'102_ME');
Insert into offers values(102,'102_CHE');
Insert into offers values(102,'102_CE');
Insert into offers values(102,'102_IT');
Insert into offers values(102,'102_ECE');


Insert into offers values(103,'103_CSE');
Insert into offers values(103,'103_ECE');
Insert into offers values(103,'103_ME');
Insert into offers values(103,'103_CHE');
Insert into offers values(103,'103_CE');
Insert into offers values(103,'103_IT');
Insert into offers values(103,'103_EE');

Insert into offers values(104,'104_CSE');
Insert into offers values(104,'104_EE');
Insert into offers values(104,'104_ECE');
Insert into offers values(104,'104_ME');
Insert into offers values(104,'104_CHE');
Insert into offers values(104,'104_CE');
Insert into offers values(104,'104_IT');


Insert into offers values(105,'105_CSE');
Insert into offers values(105,'105_CHE');
Insert into offers values(105,'105_CE');
Insert into offers values(105,'105_EE');
Insert into offers values(105,'105_IT');
Insert into offers values(105,'105_ME');
Insert into offers values(105,'105_ECE');





Insert into offers values(201,'201_IT');
Insert into offers values(201,'201_CSE');


Insert into offers values(202,'202_CSE');
Insert into offers values(202,'202_IT');

Insert into offers values(203,'203_IT');
Insert into offers values(203,'203_CSE');

Insert into offers values(204,'204_CSE');
Insert into offers values(204,'204_IT');

Insert into offers values(205,'205_CSE');
Insert into offers values(205,'205_IT');

Insert into offers values(206,'206_CSE');
Insert into offers values(206,'206_IT');

Insert into offers values(207,'207_CSE');
Insert into offers values(207,'207_IT');

Insert into offers values(208,'208_CSE');
Insert into offers values(208,'208_IT');

Insert into offers values(209,'209_CSE');
Insert into offers values(209,'209_IT');

Insert into offers values(210,'210_CSE');
Insert into offers values(210,'210_IT');
