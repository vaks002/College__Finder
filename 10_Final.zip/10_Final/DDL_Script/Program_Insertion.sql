\\NIT 1
insert into program Values('101_CSE','Computer Science',60,'6.0',78,'amazon','1:3','AI_GEN',2500,7000,'HS_GEN',4056,8000,101);
insert into program Values('101_IT','Information Technology',60,'10.00',100,'amazon','1:3','AI_GEN',1501,5027,'HS_GEN',2345,3456,101);
insert into program Values('101_ME','Mechanical Engineering',60,'7.00',50,'Reliance India Limited','1:3','AI_GEN',10300,12034,'HS_GEN',13056,15031,101);
insert into program Values('101_EE','Electrical Engineering',60,'8.80',60,'SAIL','1:3','AI_GEN',10356,14034,'HS_GEN',15056,16031,101);
insert into program Values('101_ECE','Electronics & Communication',60,'9.00',70,'L.G','1:3','AI_GEN',11356,15034,'HS_GEN',14056,1563,101);
insert into program Values('101_CHE','Chemical Engineering',60,'5.00',60,'Narolac Paint','1:3','AI_GEN',15654,17034,'HS_GEN',16056,18031,101);
insert into program Values('101_CE','Civil Engineering',60,'6.00',60,'L&T','1:3','AI_GEN',16654,18034,'HS_GEN',17056,19039,101);

\\NIT 2

insert into program Values('102_CSE','Computer Science',60,'7.00',78,'FossAsia','1:3','AI_GEN',2678,7000,'HS_GEN',4000,8000,102);
insert into program Values('102_IT','Information Technology',60,'11.00',100,'Facebook','1:3','AI_GEN',1701,5027,'HS_GEN',2345,3456,102);
insert into program Values('102_ME','Mechanical Engineering',60,'7.50',50,'Tata Motors','1:3','AI_GEN',11300,13034,'HS_GEN',14056,16031,102);
insert into program Values('102_EE','Elecrical Engineering',60,'8.50',60,'ATOS','1:3','AI_GEN',8356,10034,'HS_GEN',13056,15031,102);
insert into program Values('102_ECE','Electronics & Communication',60,'9.60',70,'Philips','1:3','AI_GEN',9356,13034,'HS_GEN',12056,14631,102);
insert into program Values('102_CHE','Chemical Engineering',60,'5.70',60,'GAIL','1:3','AI_GEN',14654,16034,'HS_GEN',17056,19031,102);
insert into program Values('102_CE','Civil Engineering',70,'7.00',60,'Indian Railways','1:3','AI_GEN',14654,16034,'HS_GEN',15056,17039,102);


\\NIT 3
insert into program Values('103_CSE','Computer Science',60,'8.80',80,'OLA','1:3','AI_GEN',2567,7000,'HS_GEN',4099,8000,103);
insert into program Values('103_IT','Information Technology',60,'11.00',89,'Uber','1:3','AI_GEN',1567,5027,'HS_GEN',2345,3456,103);
insert into program Values('103_ME','Mechanical Engineering',60,'7.00',50,'Maruti Suzuki','1:3','AI_GEN',10307,12034,'HS_GEN',13056,15031,103);
insert into program Values('103_EE','Electrical Engineering',60,'8.80',60,'SAIL','1:3','AI_GEN',10356,14034,'HS_GEN',15056,16031,103);
insert into program Values('103_ECE','Electronics & Communication',60,'9.00',70,'Samsung','1:3','AI_GEN',11356,15034,'HS_GEN',14056,15631,103);
insert into program Values('103_CHE','Chemical Engineering',60,'5.00',60,'Reliance cement','1:3','AI_GEN',15654,17034,'HS_GEN',16056,18031,103);
insert into program Values('103_CE','Civil Engineering',60,'6.00',60,'L&T','1:3','AI_GEN',16654,18030,'HS_GEN',17056,19030,103);


\\NIT 4
insert into program Values('104_CSE','Computer Science',60,'12.00',90,'Google','1:3','AI_GEN',500,1200,'HS_GEN',1590,2500,104);
insert into program Values('104_IT','Information Technology',60,'12.00',100,'Oracle','1:3','AI_GEN',701,1227,'HS_GEN',1045,3456,104);
insert into program Values('104_ME','Mechanical Engineering',60,'7.00',50,'Reliance India Limited','1:3','AI_GEN',1590,2034,'HS_GEN',13056,15031,104);
insert into program Values('104_EE','Elecrical Engineering',60,'10.00',60,'ATOS','1:3','AI_GEN',3356,4034,'HS_GEN',5056,6031,104);
insert into program Values('104_ECE','Electronics & Communication',60,'11.00',70,'L.G','1:3','AI_GEN',11356,15034,'HS_GEN',14056,15631,104);
insert into program Values('104_CHE','Chemical Engineering',60,'9.00',60,'Reliance cement','1:3','AI_GEN',15654,17034,'HS_GEN',6056,8031,104);
insert into program Values('104_CE','Civil Engineering',60,'8.80',60,'DHLF','1:3','AI_GEN',16654,18034,'HS_GEN',7056,9039,104);



\\NIT 5

insert into program Values('105_CSE','Computer Science',60,'12.00',78,'Galvin','1:3','AI_GEN',500,1200,'HS_GEN',1590,2500,105);
insert into program Values('105_IT','Information Technology',60,'12.00',100,'Facebook','1:3','AI_GEN',701,1227,'HS_GEN',1045,3456,105);
insert into program Values('105_ME','Mechanical Engineering',60,'7.00',50,'Reliance India Limited','1:3','AI_GEN',1590,2034,'HS_GEN',13056,15031,105);
insert into program Values('105_ECE','Electronics & Communication',60,'11.00',70,'Philips','1:3','AI_GEN',11356,15034,'HS_GEN',4056,5631,105);
insert into program Values('105_EE','Electrical Engineering',60,'10.00',60,'BHEL','1:3','AI_GEN',3356,4034,'HS_GEN',5056,6031,105);
insert into program Values('105_CHE','Chemical Engineering',60,'9.00',60,'GAIL','1:3','AI_GEN',15654,17034,'HS_GEN',6056,8031,105);
insert into program Values('105_CE','Civil Engineering',60,'8.80',60,'CCS','1:3','AI_GEN',16654,18034,'HS_GEN',7056,9039,105);

\\IIIT 1
insert into program Values('201_CSE','Computer Science',50,'7.0',70,'paytm','1:4','AI_GEN',22780,'29976',NULL,NULL,NULL,201);
insert into program Values('201_IT','Information Technology',50,'9.50',95,'Paytm','1:4','AI_GEN',14899,19876,NULL,NULL,NULL,201);



\\IIIT 2

insert into program Values('202_CSE','Computer Science',50,'7.8',79,'Paypal','1:4','AI_GEN',15780,25976,NULL,NULL,NULL,202);
insert into program Values('202_IT','Information Technology',50,'10.50',99,'SONY','1:4','AI_GEN',14899,19876,NULL,NULL,NULL,202);

\\IIIT 3

insert into program Values('203_CSE','Computer Science',50,'11.80',89,'Lenovo','1:4','AI_GEN',11780,15976,NULL,NULL,NULL,203);
insert into program Values('203_IT','Information Technology',50,'11.50',92,'Intel','1:4','AI_GEN',11899,14876,NULL,NULL,NULL,203);


\\IIIT 4
insert into program Values('204_CSE','Computer Science',50,'6.8',79,'jio','1:4','AI_GEN',18980,26976,NULL,NULL,NULL,204);
insert into program Values('204_IT','Information Technology',50,'7.50',99,'amazon','1:4','AI_GEN',14899,19876,NULL,NULL,NULL,204);

\\IIIT 5
insert into program Values('205_CSE','Computer Science',50,'6.9',80,'HP','1:2','AI_GEN',19780,27976,NULL,NULL,NULL,205);
 Insert into program Values('205_IT','Information Technology',50,'7.50',99,'Idea','1:2','AI_GEN',14899,19876,NULL,NULL,NULL,205);

 \\IIIT 6
 insert into program Values('206_CSE','Computer Science',50,'8.9',85,'jio','1:5','AI_GEN',10780,17976,NULL,NULL,NULL,206);
insert into program Values('206_IT','Information Technology',50,'8.50',95,'amazon','1:5','AI_GEN',14899,19876,NULL,NULL,NULL,206);

\\IIIT 7
insert into program Values('207_CSE','Computer Science',50,'7.9',85,'Reliance','1:3','AI_GEN',11780,15976,NULL,NULL,NULL,207);
insert into program Values('207_IT','Information Technology',50,'7.50',95,'Paytm','1:3','AI_GEN',14899,16876,NULL,NULL,NULL,207);


\\IIIT 8
insert into program Values('208_CSE','Computer Science',50,'8.20',85,'HP','1:5','AI_GEN',8780,9976,NULL,NULL,NULL,208);
insert into program Values('208_IT','Information Technology',50,'8.60',95,'Intel','1:5','AI_GEN',8899,9876,NULL,NULL,NULL,208);

\\IIIT 9
insert into program Values('209_CSE','Computer Science',50,'9.90',85,'Micrsoft','1:5','AI_GEN',8965,11976,NULL,NULL,NULL,209);
insert into program Values('209_IT','Information Technology',50,'9.50',95,'ICICI','1:5','AI_GEN',4899,9876,NULL,NULL,NULL,209);

\\IIIT 10
insert into program Values('210_CSE','Computer Science',50,'12.90',97,'Facebook','1:5','AI_GEN',180,976,NULL,NULL,NULL,210);
insert into program Values('210_IT','Information Technology',50,'14.50',95,'Intel','1:5','AI_GEN',199,876,NULL,NULL,NULL,210);










\\ST






\\NIT 1

insert into program Values('101_CSE','Computer Science',60,'6.00',78,'amazon','1:3','AI_ST',25,70,'HS_ST',40,80,101);
insert into program Values('101_IT','Information Technology',60,'10.00',100,'amazon','1:3','AI_ST',100,150,'HS_ST',130,190,101,101);
insert into program Values('101_ME','Mechanical Engineering',60,'7.00',50,'Reliance India Limited','1:3','AI_ST',70,90,'HS_ST',90,130,101);
insert into program Values('101_EE','Electrical Engineering',60,'8.00',60,'SAIL','1:3','AI_ST',200,251,'HS_ST',302,412,101);
insert into program Values('101_ECE','Electronics & Communication',60,'9.00',70,'L.G','1:3','AI_ST',82,99,'HS_ST',140,250,101);
insert into program Values('101_CHE','Chemical Engineering',60,'5.00',60,'Narolac Paint','1:3','AI_ST',250,395,'HS_ST',913,1006,101);
insert into program Values('101_CE','Civil Engineering',60,'6.00',60,'L&T','1:3','AI_ST',395,413,'HS_ST',178,259,101);





  insert into program Values('102_CSE','Computer Science',60,'7.00',78,'FossAsia','1:3','AI_ST',106,852,'HS_ST',456,951,102);
 insert into program Values('102_IT','Information Technology',60,'11.00',100,'Facebook','1:3','AI_ST',365,631,'HS_ST',851,1109,102);
 insert into program Values('102_ME','Mechanical Engineering',60,'7.50',50,'Tata Motors','1:3','AI_ST',534,963,'HS_ST',753,1134,102);
insert into program Values('102_EE','Electrical Engineering',60,'8.50',60,'ATOS','1:3','AI_ST',1134,1640,'HS_ST',1203,1642,102);
insert into program Values('102_ECE','Electronics & Communication',60,'9.60',70,'Philips','1:3','AI_ST',951,963,'HS_ST',1194,1364,102);
insert into program Values('102_CHE','Chemical Engineering',60,'5.70',60,'GAIL','1:3','AI_ST',1345,1643,'HS_ST',1731,1931,102);
insert into program Values('102_CE','Civil Engineering',60,'7.00',60,'Indian Railways','1:3','AI_ST',1345,1643,'HS_ST',1931,2014,102);







insert into program Values('103_CSE','Computer Science',60,'8.00',80,'OLA','1:3','AI_ST',1267,1570,'HS_ST',1499,1880,103);
insert into program Values('103_IT','Information Technology',60,'11.00',89,'Uber','1:3','AI_ST',1567,1590,'HS_ST',1390,1390,103);
insert into program Values('103_ME','Mechanical Engineering',60,'7.00',50,'Maruti Suzuki','1:3','AI_ST',1883,250,'HS_ST',2090,2330,103);
insert into program Values('103_EE','Electrical Engineering',60,'8.00',60,'SAIL','1:3','AI_ST',2006,2251,'HS_ST',2303,2412,103);
insert into program Values('103_ECE','Electronics & Communication',60,'9.00',70,'Samsung','1:3','AI_ST',1482,1799,'HS_ST',1540,2050,103);
insert into program Values('103_CHE','Chemical Engineering',60,'5.00',60,'Reliance cement','1:3','AI_ST',250,395,'HS_ST',903,1006,103);
insert into program Values('103_CE','Civil Engineering',60,'6.00',60,'L&T','1:3','AI_ST',395,563,'HS_ST',978,1259,103);







insert into program Values('104_CSE','Computer Science',60,'12.00',90,'Google','1:3','AI_ST',133,234,'HS_ST',485,525,104);
insert into program Values('104_IT','Information Technology',60,'12.00',100,'Oracle','1:3','AI_ST',254,455,'HS_ST',678,790,104)
insert into program Values('104_ME','Mechanical Engineering',60,'7.00',50,'Reliance India Limited','1:3','AI_ST',85,95,'HS_ST',90,130,104);
insert into program Values('104_EE','Electrical Engineering',60,'10.00',60,'ATOS','1:3','AI_ST',1000,1011,'HS_ST',3012,5014,104);
insert into program Values('104_ECE','Electronics & Communication',60,'11.00',70,'L.G','1:3','AI_ST',2014,2145,'HS_ST',3440,5631,104);
insert into program Values('104_CHE','Chemical Engineering',60,'9.00',60,'Reliance cement','1:3','AI_ST',250,395,'HS_ST',901,1006,104);
insert into program Values('104_CE','Civil Engineering',60,'8.00',60,'DHLF','1:3','AI_ST',395,813,'HS_ST',1040,2159,104);





 insert into program Values('105_CSE','Computer Science',60,'12.00',78,'Galvin','1:3','AI_ST',13,24,'HS_ST',85,95,105);
insert into program Values('105_IT','Information Technology',60,'12.00',100,'Facebook','1:3','AI_ST',24,45,'HS_ST',78,90,105);
insert into program Values('105_ME','Mechanical Engineering',60,'7.00',50,'Reliance India Limited','1:3','AI_ST',85,95,'HS_ST',90,130,105);
insert into program Values('105_ECE','Electronics & Communication',60,'11.00',70,'Philips','1:3','AI_ST',2014,2145,'HS_ST',4250,5631,105);
  insert into program Values('105_EE','Electrical Engineering',60,'10.00',60,'BHEL','1:3','AI_ST',1000,1011,'HS_ST',3012,5014,105);
insert into program Values('105_CHE','Chemical Engineering',60,'9.00',60,'GAIL','1:3','AI_ST',250,395,'HS_ST',901,1006,105);
insert into program Values('105_CE','Civil Engineering',60,'8.00',60,'CCS','1:3','AI_ST',395,913,'HS_ST',1378,2559,105);




 \\IIIT 1

insert into program Values('201_CSE','Computer Science',50,'7.0',70,'paytm','1:4','AI_ST',81,97,'null','null','null',201);
insert into program Values('201_IT','Information Technology',50,'9.50',95,'PAytm','1:4','AI_ST',113,135,'null','null','null',201);


\\IIIT 2
insert into program Values('202_CSE','Computer Science',50,'7.8',79,'Paypal','1:4','AI_ST',1652,2219,'null','null','null',202);
insert into program Values('202_IT','Information Technology',50,'10.50',99,'Sony','1:4','AI_ST',1313,2035,'null','null','null',202);

\\IIIT 3

insert into program Values('203_CSE','Computer Science',50,'11.8',89,'Lenovo','1:4','AI_ST',3233,3439,'null','null','null',203);
insert into program Values('203_IT','Information Technology',50,'11.50',92,'Intel','1:4','AI_ST',4035,4351,'null','null','null',203);

\\IIIT 4

insert into program Values('204_CSE','Computer Science',50,'6.8',79,'jio','1:4','AI_ST',4351,4613,'null','null','null',204);
insert into program Values('204_IT','Information Technology',50,'7.50',99,'amazon','1:4','AI_ST',2113,3035,'null','null','null',204);

\\ IIIT 5
insert into program Values('205_CSE','Computer Science',50,'6.9',80,'HP','1:2','AI_ST',4387,5349,'null','null','null',205);
insert into program Values('205_IT','Information Technology',50,'7.50',99,'idea','1:2','AI_ST',5113,6035,'null','null','null',205);

\\IIIT 6

insert into program Values('206_CSE','Computer Science',50,'8.9',85,'jio','1:5','AI_ST',5107,6137,'null','null','null',206);
insert into program Values('206_IT','Information Technology',50,'8.50',95,'amazon','1:5','AI_ST',5113,7035,'null','null','null',206);


\\IIIT 7

insert into program Values('207_CSE','Computer Science',50,'7.9',85,'Reliance','1:3','AI_ST',3233,3439,'null','null','null'207);
insert into program Values('207_IT','Information Technology',50,'7.50',95,'Paytm','1:3','AI_ST',4113,5142,'null','null','null'207);


\\IIIT 8
insert into program Values('208_CSE','Computer Science',50,'8.2',85,'HP','1:5','AI_ST',8780,9976,'null','null','null'208);
insert into program Values('208_IT','Information Technology',50,'8.60',95,'Intel','1:5','AI_ST',8899,10265,'null','null','null'208);


\\IIIT 9
insert into program Values('209_CSE','Computer Science',50,'9.9',85,'Micrsoft','1:5','AI_ST',4965,5976,'null','null','null'209);
insert into program Values('209_IT','Information Technology',50,'9.50',95,'ICICI','1:5','AI_ST',4899,5265,'null','null','null'209);


\\IIIT 10
insert into program Values('210_CSE','Computer Science',50,'12.9',97,'Facebook','1:5','AI_ST',1080,1976,'null','null','null'210);
insert into program Values('210_IT','Information Technology',50,'14.50',95,'Intel','1:5','AI_ST',599,876,'null','null','null'210);
