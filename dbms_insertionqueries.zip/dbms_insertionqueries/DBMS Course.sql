INSERT INTO course Values ('Computer Networks', 'CS01', '101_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS02', '101_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS03', '101_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS04', '101_CSE');
INSERT INTO course Values ('Operating Systems', 'CS05', '101_CSE');
INSERT INTO course Values ('Computer Organization ', 'CS06', '101_CSE');
INSERT INTO course Values ('software engineering', 'CS07', '101_CSE');





INSERT INTO course Values ( 'Computational Fluid Dynamics', 'ME01', '101_ME');
INSERT INTO course Values ('Modelling of Turbulent Combustion', 'ME02', '101_ME');
INSERT INTO course Values ('Computer Aided Design of Thermal Systems', 'ME03', '101_ME');
INSERT INTO course Values ('Industrial Engineering ', 'ME04', '101_ME');
INSERT INTO course Values ('Railroad Vehicle Dynamics', 'ME05', '101_ME');
INSERT INTO course Values (' Principle of Vibration Control', 'ME06', '101_ME');
INSERT INTO course Values ('Robot Manipulators Dynamics ', 'ME07', '101_ME');
INSERT INTO course Values (' Wave propagation in solids', 'ME08', '101_ME');





INSERT INTO course Values ('Basics of Electronics Engineering', 'EE01', '101_EE');
INSERT INTO course Values ('Fiber-optics', 'EE02', '101_EE');
INSERT INTO course Values ('Signals systems and networks', 'EE03', '101_EE');
INSERT INTO course Values ('Power Systems', 'EE04', '101_EE');
INSERT INTO course Values ('Electrical machines', 'EE05', '101_EE');
INSERT INTO course Values ('Introduction to manufacturingprocesses ','EE06', '101_EE');
INSERT INTO course Values ('Semiconductor DevicesTechnology', 'EE07', '101_EE');





INSERT INTO course Values ('Civil Engineering Materials', 'CE01', '101_CE');
INSERT INTO course Values ('Construction Practices', 'CE02', '101_CE');
INSERT INTO course Values ('Soil Mechanics', 'CE03', '101_CE');
INSERT INTO course Values ('Construction Management', 'CE04', '101_CE');
INSERT INTO course Values ('Elements of Surveying', 'CE05', '101_CE');
INSERT INTO course Values (' Transportation Engineering ', 'CE06', '101_CE');
INSERT INTO course Values ('Environmental Engineering', 'CE07', '101_CE');



INSERT INTO course Values ('Introduction To IT', 'IT01', '101_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT02', '101_IT');
INSERT INTO course Values ('Operations Research ', 'IT03', '101_IT');
INSERT INTO course Values ('Cloud Computing', 'IT04', '101_IT');
INSERT INTO course Values ('Database Management System', 'IT05', '101_IT');
INSERT INTO course Values (' Information Security', 'IT06', '101_IT');101_
INSERT INTO course Values ('Computer Networks', 'IT07', '101_IT');






INSERT INTO course Values ('Air Pollution Control Engineering', 'CHE01', '101_CHE');
INSERT INTO course Values ('Chemical Engineering Economics and Plant Design', 'CHE02', '101_CHE');
INSERT INTO course Values ('Chemical Process Industries', 'CHE03', '101_CHE');
INSERT INTO course Values ('Material Science', 'CHE04', '101_CHE');
INSERT INTO course Values ('Pharmaceutical Technology', 'CHE05', '101_CHE');
INSERT INTO course Values (' Process Fluid Mechanics', 'CHE06', '101_CHE');
INSERT INTO course Values ('Process Equipment Design', 'CHE07', '101_CHE');


































INSERT INTO course Values ('Computer Networks', 'CS11', '102_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS12', '102_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS13', '102_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS14', '102_CSE');
INSERT INTO course Values ('Operating Systems', 'CS15', '102_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS16', '102_CSE');
INSERT INTO course Values ('software engineering', 'CS17', '102_CSE');





INSERT INTO course Values ( 'Computational Fluid Dynamics and Heat Transfer', 'ME11', '102_ME');
INSERT INTO course Values ('Modelling of Turbulent Combustion', 'ME12', '102_ME');
INSERT INTO course Values ('Computer Aided Design of Thermal Systems', 'ME13', '102_ME');
INSERT INTO course Values ('Industrial Engineering and Operation Research', 'ME14', '102_ME');
INSERT INTO course Values ('Railroad Vehicle Dynamics', 'ME15', '102_ME');
INSERT INTO course Values (' Principle of Vibration Control', 'ME16', '102_ME');
INSERT INTO course Values ('Robot Manipulators Dynamics and Control', 'ME17', '102_ME');
INSERT INTO course Values (' Wave propagation in solids', 'ME18', '102_ME');





INSERT INTO course Values ('Basics of Electronics Engineering', 'EE11', '102_EE');
INSERT INTO course Values ('Fiber-optics', 'EE12', '102_EE');
INSERT INTO course Values ('Signals systems and networks', 'EE13', '102_EE');
INSERT INTO course Values ('Power Systems', 'EE14', '102_EE');
INSERT INTO course Values ('Electrical machines', 'EE15', '102_EE');
INSERT INTO course Values ('Introduction to manufacturing processes ','EE16', '102_EE');
INSERT INTO course Values ('Semiconductor Devices Technology', 'EE17', '102_EE');





INSERT INTO course Values ('Civil Engineering Materials', 'CE11', '102_CE');
INSERT INTO course Values ('Construction Practices', 'CE12', '102_CE');
INSERT INTO course Values ('Soil Mechanics', 'CE13', '102_CE');
INSERT INTO course Values ('Construction Management', 'CE14', '102_CE');
INSERT INTO course Values ('Elements of Surveying', 'CE15', '102_CE');
INSERT INTO course Values ('Introduction to Transportation Engineering ', 'CE16', '102_CE');
INSERT INTO course Values ('Environmental Engineering', 'CE17', '102_CE');






INSERT INTO course Values ('Computer Programming for Engineering Applications', 'EC11', '102_ECE');
INSERT INTO course Values ('Basic Circuits', 'EC12', '102_ECE');
INSERT INTO course Values ('Elements of Electrical Engineering', 'EC13', '102_ECE');
INSERT INTO course Values ('Digital Signal Processing', 'EC14', '102_ECE');
INSERT INTO course Values ('Microprocessor Organization', 'EC15', '102_ECE');
INSERT INTO course Values ('Digital Communications Systems ', 'EC16', '102_ECE');
INSERT INTO course Values ('Fundamentals of Optics for Electrical Engineers', 'EC17', '102_ECE');




INSERT INTO course Values ('Introduction To Information Technology', 'IT11', '102_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT12', '102_IT');
INSERT INTO course Values ('Operations Research ', 'IT13', '102_IT');
INSERT INTO course Values ('Cloud Computing', 'IT14', '102_IT');
INSERT INTO course Values ('Database Management System', 'IT15', '102_IT');
INSERT INTO course Values (' Information Security', 'IT16', '102_IT');
INSERT INTO course Values ('Computer Networks', 'IT17', '102_IT');






INSERT INTO course Values ('Air Pollution Control Engineering', 'CHE11', '102_CHE');
INSERT INTO course Values ('Chemical Engineering Economics and Plant Design', 'CHE12', '102_CHE');
INSERT INTO course Values ('Chemical Process Industries', 'CHE13', '102_CHE');
INSERT INTO course Values ('Material Science', 'CHE14', '102_CHE');
INSERT INTO course Values ('Pharmaceutical Technology', 'CHE15', '102_CHE');
INSERT INTO course Values (' Process Fluid Mechanics', 'CHE16', '102_CHE');
INSERT INTO course Values ('Process Equipment Design', 'CHE17', '102_CHE');











































INSERT INTO course Values ('Computer Networks', 'CS21', '103_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS22', '103_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS23', '103_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS24', '103_CSE');
INSERT INTO course Values ('Operating Systems', 'CS25', '103_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS26', '103_CSE');
INSERT INTO course Values ('software engineering', 'CS27', '103_CSE');





INSERT INTO course Values ( 'Computational Fluid Dynamics and Heat Transfer', 'ME21', '103_ME');
INSERT INTO course Values ('Modelling of Turbulent Combustion', 'ME22', '103_ME');
INSERT INTO course Values ('Computer Aided Design of Thermal Systems', 'ME23', '103_ME');
INSERT INTO course Values ('Industrial Engineering and Operation Research', 'ME24', '103_ME');
INSERT INTO course Values ('Railroad Vehicle Dynamics', 'ME25', '103_ME');
INSERT INTO course Values (' Principle of Vibration Control', 'ME26', '103_ME');
INSERT INTO course Values ('Robot Manipulators Dynamics and Control', 'ME27', '103_ME');
INSERT INTO course Values (' Wave propagation in solids', 'ME28', '103_ME');





INSERT INTO course Values ('Basics of Electronics Engineering', 'EE21', '103_EE');
INSERT INTO course Values ('Fiber-optics', 'EE22', '103_EE');
INSERT INTO course Values ('Signals systems and networks', 'EE23', '103_EE');
INSERT INTO course Values ('Power Systems', 'EE24', '103_EE');
INSERT INTO course Values ('Electrical machines', 'EE25', '103_EE');
INSERT INTO course Values ('Introduction to manufacturing processes ','EE26', '103_EE');
INSERT INTO course Values ('Semiconductor Devices Technology', 'EE27', '103_EE');





INSERT INTO course Values ('Civil Engineering Materials', 'CE21', '103_CE');
INSERT INTO course Values ('Construction Practices', 'CE22', '103_CE');
INSERT INTO course Values ('Soil Mechanics', 'CE23', '103_CE');
INSERT INTO course Values ('Construction Management', 'CE24', '103_CE');
INSERT INTO course Values ('Elements of Surveying', 'CE25', '103_CE');
INSERT INTO course Values ('Introduction to Transportation Engineering ', 'CE26', '103_CE');
INSERT INTO course Values ('Environmental Engineering', 'CE27', '103_CE');






INSERT INTO course Values ('Computer Programming for Engineering Applications', 'EC21', '103_ECE');
INSERT INTO course Values ('Basic Circuits', 'EC22', '103_ECE');
INSERT INTO course Values ('Elements of Electrical Engineering', 'EC23', '103_ECE');
INSERT INTO course Values ('Digital Signal Processing', 'EC24', '103_ECE');
INSERT INTO course Values ('Microprocessor Organization', 'EC25', '103_ECE');
INSERT INTO course Values ('Digital Communications Systems ', 'EC26', '103_ECE');
INSERT INTO course Values ('Fundamentals of Optics for Electrical Engineers', 'EC27', '103_ECE');




INSERT INTO course Values ('Introduction To Information Technology', 'IT21', '103_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT22', '103_IT');
INSERT INTO course Values ('Operations Research ', 'IT23', '103_IT');
INSERT INTO course Values ('Cloud Computing', 'IT24', '103_IT');
INSERT INTO course Values ('Database Management System', 'IT25', '103_IT');
INSERT INTO course Values (' Information Security', 'IT26', '103_IT');
INSERT INTO course Values ('Computer Networks', 'IT27', '103_IT');






INSERT INTO course Values ('Air Pollution Control Engineering', 'CHE21', '103_CHE');
INSERT INTO course Values ('Chemical Engineering Economics and Plant Design', 'CHE22', '103_CHE');
INSERT INTO course Values ('Chemical Process Industries', 'CHE23', '103_CHE');
INSERT INTO course Values ('Material Science', 'CHE24', '103_CHE');
INSERT INTO course Values ('Pharmaceutical Technology', 'CHE25', '103_CHE');
INSERT INTO course Values (' Process Fluid Mechanics', 'CHE26', '103_CHE');
INSERT INTO course Values ('Process Equipment Design', 'CHE27', '103_CHE');




































INSERT INTO course Values ('Computer Networks', 'CS31', '104_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS32', '104_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS33', '104_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS34', '104_CSE');
INSERT INTO course Values ('Operating Systems', 'CS35', '104_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS36', '104_CSE');
INSERT INTO course Values ('software engineering', 'CS37', '104_CSE');





INSERT INTO course Values ( 'Computational Fluid Dynamics and Heat Transfer', 'ME31', '104_ME');
INSERT INTO course Values ('Modelling of Turbulent Combustion', 'ME32', '104_ME');
INSERT INTO course Values ('Computer Aided Design of Thermal Systems', 'ME33', '104_ME');
INSERT INTO course Values ('Industrial Engineering and Operation Research', 'ME34', '104_ME');
INSERT INTO course Values ('Railroad Vehicle Dynamics', 'ME35', '104_ME');
INSERT INTO course Values (' Principle of Vibration Control', 'ME36', '104_ME');
INSERT INTO course Values ('Robot Manipulators Dynamics and Control', 'ME37', '104_ME');
INSERT INTO course Values (' Wave propagation in solids', 'ME38', '104_ME');





INSERT INTO course Values ('Basics of Electronics Engineering', 'EE31', '104_EE');
INSERT INTO course Values ('Fiber-optics', 'EE32', '104_EE');
INSERT INTO course Values ('Signals systems and networks', 'EE03', '104_EE');
INSERT INTO course Values ('Power Systems', 'EE34', '104_EE');
INSERT INTO course Values ('Electrical machines', 'EE35', '104_EE');
INSERT INTO course Values ('Introduction to manufacturing processes ','EE36', '104_EE');
INSERT INTO course Values ('Semiconductor Devices Technology', 'EE37', '104_EE');





INSERT INTO course Values ('Civil Engineering Materials', 'CE31', '104_CE');
INSERT INTO course Values ('Construction Practices', 'CE32', '104_CE');
INSERT INTO course Values ('Soil Mechanics', 'CE33', '104_CE');
INSERT INTO course Values ('Construction Management', 'CE34', '104_CE');
INSERT INTO course Values ('Elements of Surveying', 'CE35', '104_CE');
INSERT INTO course Values ('Introduction to Transportation Engineering ', 'CE36', '104_CE');
INSERT INTO course Values ('Environmental Engineering', 'CE37', '104_CE');






INSERT INTO course Values ('Computer Programming for Engineering Applications', 'EC31', '104_ECE');
INSERT INTO course Values ('Basic Circuits', 'EC32', '104_ECE');
INSERT INTO course Values ('Elements of Electrical Engineering', 'EC33', '104_ECE');
INSERT INTO course Values ('Digital Signal Processing', 'EC34', '104_ECE');
INSERT INTO course Values ('Microprocessor Organization', 'EC35', '104_ECE');
INSERT INTO course Values ('Digital Communications Systems ', 'EC36', '104_ECE');
INSERT INTO course Values ('Fundamentals of Optics for Electrical Engineers', 'EC37', '104_ECE');




INSERT INTO course Values ('Introduction To Information Technology', 'IT31', '104_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT32', '104_IT');
INSERT INTO course Values ('Operations Research ', 'IT33', '104_IT');
INSERT INTO course Values ('Cloud Computing', 'IT34', '104_IT');
INSERT INTO course Values ('Database Management System', 'IT35', '104_IT');
INSERT INTO course Values (' Information Security', 'IT36', '104_IT');
INSERT INTO course Values ('Computer Networks', 'IT37', '104_IT');






INSERT INTO course Values ('Air Pollution Control Engineering', 'CHE31', '104_CHE');
INSERT INTO course Values ('Chemical Engineering Economics and Plant Design', 'CHE32', '104_CHE');
INSERT INTO course Values ('Chemical Process Industries', 'CHE33', '104_CHE');
INSERT INTO course Values ('Material Science', 'CHE34', '104_CHE');
INSERT INTO course Values ('Pharmaceutical Technology', 'CHE35', '104_CHE');
INSERT INTO course Values (' Process Fluid Mechanics', 'CHE36', '104_CHE');
INSERT INTO course Values ('Process Equipment Design', 'CHE37', '104_CHE');














































INSERT INTO course Values ('Computer Networks', 'CS41', '105_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS42', '105_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS43', '105_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS44', '105_CSE');
INSERT INTO course Values ('Operating Systems', 'CS45', '105_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS46', '105_CSE');
INSERT INTO course Values ('software engineering', 'CS47', '105_CSE');





INSERT INTO course Values ( 'Computational Fluid Dynamics and Heat Transfer', 'ME41', '105_ME');
INSERT INTO course Values ('Modelling of Turbulent Combustion', 'ME42', '105_ME');
INSERT INTO course Values ('Computer Aided Design of Thermal Systems', 'ME43', '105_ME');
INSERT INTO course Values ('Industrial Engineering and Operation Research', 'ME44', '105_ME');
INSERT INTO course Values ('Railroad Vehicle Dynamics', 'ME45', '105_ME');
INSERT INTO course Values (' Principle of Vibration Control', 'ME46', '105_ME');
INSERT INTO course Values ('Robot Manipulators Dynamics and Control', 'ME47', '105_ME');
INSERT INTO course Values (' Wave propagation in solids', 'ME48', '105_ME');





INSERT INTO course Values ('Basics of Electronics Engineering', 'EE41', '105_EE');
INSERT INTO course Values ('Fiber-optics', 'EE42', '105_EE');
INSERT INTO course Values ('Signals systems and networks', 'EE43', '105_EE');
INSERT INTO course Values ('Power Systems', 'EE44', '105_EE');
INSERT INTO course Values ('Electrical machines', 'EE45', '105_EE');
INSERT INTO course Values ('Introduction to manufacturing processes ','EE46', '105_EE');
INSERT INTO course Values ('Semiconductor Devices Technology', 'EE47', '105_EE');





INSERT INTO course Values ('Civil Engineering Materials', 'CE41', '105_CE');
INSERT INTO course Values ('Construction Practices', 'CE42', '105_CE');
INSERT INTO course Values ('Soil Mechanics', 'CE43', '105_CE');
INSERT INTO course Values ('Construction Management', 'CE44', '105_CE');
INSERT INTO course Values ('Elements of Surveying', 'CE45', '105_CE');
INSERT INTO course Values ('Introduction to Transportation Engineering ', 'CE46', '105_CE');
INSERT INTO course Values ('Environmental Engineering', 'CE47', '105_CE');






INSERT INTO course Values ('Computer Programming for Engineering Applications', 'EC41', '105_ECE');
INSERT INTO course Values ('Basic Circuits', 'EC42', '105_ECE');
INSERT INTO course Values ('Elements of Electrical Engineering', 'EC43', '105_ECE');
INSERT INTO course Values ('Digital Signal Processing', 'EC44', '105_ECE');
INSERT INTO course Values ('Microprocessor Organization', 'EC45', '105_ECE');
INSERT INTO course Values ('Digital Communications Systems ', 'EC46', '105_ECE');
INSERT INTO course Values ('Fundamentals of Optics for Electrical Engineers', 'EC47', '105_ECE');




INSERT INTO course Values ('Introduction To Information Technology', 'IT41', '105_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT42', '105_IT');
INSERT INTO course Values ('Operations Research ', 'IT43', '105_IT');
INSERT INTO course Values ('Cloud Computing', 'IT44', '105_IT');
INSERT INTO course Values ('Database Management System', 'IT45', '105_IT');
INSERT INTO course Values (' Information Security', 'IT46', '105_IT');
INSERT INTO course Values ('Computer Networks', 'IT47', '105_IT');




INSERT INTO course Values ('Air Pollution Control Engineering', 'CHE41', '105_CHE');
INSERT INTO course Values ('Chemical Engineering Economics and Plant Design', 'CHE42', '105_CHE');
INSERT INTO course Values ('Chemical Process Industries', 'CHE43', '105_CHE');
INSERT INTO course Values ('Material Science', 'CHE44', '105_CHE');
INSERT INTO course Values ('Pharmaceutical Technology', 'CHE45', '105_CHE');
INSERT INTO course Values (' Process Fluid Mechanics', 'CHE46', '105_CHE');
INSERT INTO course Values ('Process Equipment Design', 'CHE47', '105_CHE');




















//iities





















INSERT INTO course Values ('Computer Networks', 'CS101', '201_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS102', '201_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS103', '201_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS104', '201_CSE');
INSERT INTO course Values ('Operating Systems', 'CS105', '201_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS106', '201_CSE');
INSERT INTO course Values ('software engineering', 'CS107', '201_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT101', '201_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT102', '201_IT');
INSERT INTO course Values ('Operations Research ', 'IT103', '201_IT');
INSERT INTO course Values ('Cloud Computing', 'IT104', '201_IT');
INSERT INTO course Values ('Database Management System', 'IT105', '201_IT');
INSERT INTO course Values (' Information Security', 'IT106', '201_IT');
INSERT INTO course Values ('Computer Networks', 'IT107', '201_IT');






















INSERT INTO course Values ('Computer Networks', 'CS111', '202_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS112', '202_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS113', '202_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS114', '202_CSE');
INSERT INTO course Values ('Operating Systems', 'CS115', '202_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS116', '202_CSE');
INSERT INTO course Values ('software engineering', 'CS117', '202_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT111', '202_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT112', '202_IT');
INSERT INTO course Values ('Operations Research ', 'IT113', '202_IT');
INSERT INTO course Values ('Cloud Computing', 'IT114', '202_IT');
INSERT INTO course Values ('Database Management System', 'IT115', '202_IT');
INSERT INTO course Values (' Information Security', 'IT116', '202_IT');
INSERT INTO course Values ('Computer Networks', 'IT117', '202_IT');





























INSERT INTO course Values ('Computer Networks', 'CS121', '203_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS122', '203_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS123', '203_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS124', '203_CSE');
INSERT INTO course Values ('Operating Systems', 'CS125', '203_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS126', '203_CSE');
INSERT INTO course Values ('software engineering', 'CS127', '203_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT121', '203_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT122', '203_IT');
INSERT INTO course Values ('Operations Research ', 'IT123', '203_IT');
INSERT INTO course Values ('Cloud Computing', 'IT124', '203_IT');
INSERT INTO course Values ('Database Management System', 'IT125', '203_IT');
INSERT INTO course Values (' Information Security', 'IT126', '203_IT');
INSERT INTO course Values ('Computer Networks', 'IT127', '203_IT');








































INSERT INTO course Values ('Computer Networks', 'CS131', '204_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS132', '204_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS133', '204_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS134', '204_CSE');
INSERT INTO course Values ('Operating Systems', 'CS135', '204_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS136', '204_CSE');
INSERT INTO course Values ('software engineering', 'CS137', '204_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT131', '204_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT132', '204_IT');
INSERT INTO course Values ('Operations Research ', 'IT133', '204_IT');
INSERT INTO course Values ('Cloud Computing', 'IT134', '204_IT');
INSERT INTO course Values ('Database Management System', 'IT135', '204_IT');
INSERT INTO course Values (' Information Security', 'IT136', '204_IT');
INSERT INTO course Values ('Computer Networks', 'IT137', '204_IT');
































INSERT INTO course Values ('Computer Networks', 'CS141', '205_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS142', '205_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS143', '205_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS144', '205_CSE');
INSERT INTO course Values ('Operating Systems', 'CS145', '205_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS146', '205_CSE');
INSERT INTO course Values ('software engineering', 'CS147', '205_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT141', '205_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT142', '205_IT');
INSERT INTO course Values ('Operations Research ', 'IT143', '205_IT');
INSERT INTO course Values ('Cloud Computing', 'IT144', '205_IT');
INSERT INTO course Values ('Database Management System', 'IT145', '205_IT');
INSERT INTO course Values (' Information Security', 'IT146', '205_IT');
INSERT INTO course Values ('Computer Networks', 'IT147', '205_IT');













































INSERT INTO course Values ('Computer Networks', 'CS151', '206_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS152', '206_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS153', '206_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS154', '206_CSE');
INSERT INTO course Values ('Operating Systems', 'CS155', '206_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS156', '206_CSE');
INSERT INTO course Values ('software engineering', 'CS157', '206_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT151', '206_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT152', '206_IT');
INSERT INTO course Values ('Operations Research ', 'IT153', '206_IT');
INSERT INTO course Values ('Cloud Computing', 'IT154', '206_IT');
INSERT INTO course Values ('Database Management System', 'IT155', '206_IT');
INSERT INTO course Values (' Information Security', 'IT156', '206_IT');
INSERT INTO course Values ('Computer Networks', 'IT157', '206_IT');











































INSERT INTO course Values ('Computer Networks', 'CS161', '207_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS162', '207_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS163', '207_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS164', '207_CSE');
INSERT INTO course Values ('Operating Systems', 'CS165', '207_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS166', '207_CSE');
INSERT INTO course Values ('software engineering', 'CS167', '207_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT161', '207_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT162', '207_IT');
INSERT INTO course Values ('Operations Research ', 'IT163', '207_IT');
INSERT INTO course Values ('Cloud Computing', 'IT164', '207_IT');
INSERT INTO course Values ('Database Management System', 'IT165', '207_IT');
INSERT INTO course Values (' Information Security', 'IT166', '207_IT');
INSERT INTO course Values ('Computer Networks', 'IT167', '207_IT');















































INSERT INTO course Values ('Computer Networks', 'CS171', '208_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS172', '208_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS173', '208_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS174', '208_CSE');
INSERT INTO course Values ('Operating Systems', 'CS175', '208_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS176', '208_CSE');
INSERT INTO course Values ('software engineering', 'CS177', '208_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT171', '208_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT172', '208_IT');
INSERT INTO course Values ('Operations Research ', 'IT173', '208_IT');
INSERT INTO course Values ('Cloud Computing', 'IT174', '208_IT');
INSERT INTO course Values ('Database Management System', 'IT175', '208_IT');
INSERT INTO course Values (' Information Security', 'IT176', '208_IT');
INSERT INTO course Values ('Computer Networks', 'IT177', '208_IT');
















































INSERT INTO course Values ('Computer Networks', 'CS181', '209_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS182', '209_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS183', '209_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS184', '209_CSE');
INSERT INTO course Values ('Operating Systems', 'CS185', 'CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS186', '209_CSE');
INSERT INTO course Values ('software engineering', 'CS187', '209_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT181', '209_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT182', '209_IT');
INSERT INTO course Values ('Operations Research ', 'IT183', '209_IT');
INSERT INTO course Values ('Cloud Computing', 'IT184', '209_IT');
INSERT INTO course Values ('Database Management System', 'IT185', '209_IT');
INSERT INTO course Values (' Information Security', 'IT186', '209_IT');
INSERT INTO course Values ('Computer Networks', 'IT187', '209_IT');
































INSERT INTO course Values ('Computer Networks', 'CS191', '210_CSE');
INSERT INTO course Values ('Data Structures & Algorithms', 'CS192', '210_CSE');
INSERT INTO course Values ('Data Base Management Systems', 'CS193', '210_CSE');
INSERT INTO course Values ('Design and Analysis of Algorithms', 'CS194', '210_CSE');
INSERT INTO course Values ('Operating Systems', 'CS195', '210_CSE');
INSERT INTO course Values ('Computer Organization and Architecture ', 'CS196', '210_CSE');
INSERT INTO course Values ('software engineering', 'CS197', '210_CSE');



INSERT INTO course Values ('Introduction To Information Technology', 'IT191', '210_IT');
INSERT INTO course Values ('Data Structures & Algorithms', 'IT192', '210_IT');
INSERT INTO course Values ('Operations Research ', 'IT193', '210_IT');
INSERT INTO course Values ('Cloud Computing', 'IT194', '210_IT');
INSERT INTO course Values ('Database Management System', 'IT195', '210_IT');
INSERT INTO course Values (' Information Security', 'IT196', '210_IT');
INSERT INTO course Values ('Computer Networks', 'IT197', '210_IT');
