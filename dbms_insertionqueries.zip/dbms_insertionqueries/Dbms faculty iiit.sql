


insert into Faculty Values('ZK21','Zahid kurasi',5 ,'Ph.D','CS101',201);
insert into Faculty  Values('MLD21','Manik lal Das' ,10,'MBA','CS102',201 );
insert into Faculty Values('KLS21','kailash singh',9,'Ph.D','CS103',201);
insert into Faculty Values('DIK21','Dilip kumar',11,'Ph.D','CS103',201);
insert into Faculty Values('VS21','Vanita sachan',6, 'M.TECH','CS105',201);
insert into Faculty Values('SSS21','Sanjay Singh Singhania',11, 'Ph.D','CS106',201);
insert into Faculty  Values('VS21','Vinit singh',8, 'Ph.D','CS107',201);



insert into Faculty Values('SRJ21','Smit Rajput',13 ,'Ph.D','IT101',201);
insert into Faculty  Values('SKR21','Shubham Singh' ,8,'MBA','IT102',201 );
insert into Faculty Values('SRS21','Srikant singh',9,'Ph.D','IT103',201);
insert into Faculty Values('DKS21','Direndra singh',12,'Ph.D','IT104',201);
insert into Faculty Values('GS21','Girish Singh',14, 'M.TECH','IT105',201);
insert into Faculty Values('CCS21','chanchal singh',5, 'Ph.D','IT106',201);
insert into Faculty  Values('AA21','Atif Aslam',10, 'MBA','IT107',201);





insert into Faculty Values('DS22','Dilip Singh ',4 ,'Ph.D','CS111',202);
insert into Faculty  Values('HMT22','Hemant tiwari' ,7,'MBA','CS112',202 );
insert into Faculty Values('JA22','Jitu Awasthi',6,'Ph.D','CS113',202);
insert into Faculty Values('AB22','Anil Bajpai ',2,'MBA','CS114',202);
insert into Faculty Values('RS22','Rohan Singh',10, 'M.TECH','CS115',202);
insert into Faculty Values('SM22','Suraj Meena',3, 'Ph.D','CS116',202);
insert into Faculty  Values('RK22','Ravi Kumar',8, 'MBA','CS117',202);



insert into Faculty Values('HS22',' Kunal. SHARMA',3 ,'M.TECH','IT111',202);
insert into Faculty  Values('NIK22','Nilesh Kumar' ,8,'MBA','IT112',202 );
insert into Faculty Values('RJR22','Ranjana rajput',6,'Ph.D','IT113',202);
insert into Faculty Values('PKP22','P.K panday',11,'Ph.D','IT114',202);
insert into Faculty Values('MSD22','M.S Dhoni',11, 'M.TECH','IT115',202);
insert into Faculty Values('AK22','Ashutosh Kushwaha',5, 'MBA','IT116',202);
insert into Faculty  Values('AMS22','Anup Maheswari',7, 'MBA','IT116',202);




insert into Faculty Values('MK23','Manmohan Kumar ',10 ,'Ph.D','CS121',203);
insert into Faculty  Values('NS23','Namita Sachan' ,8,'MBA','CS122',203 );
insert into Faculty Values('PKK23','PREMKUMAR K.	',9,'Ph.D','CS123',203);
insert into Faculty Values('MKC23','M.Koul',12,'MBA','CS124',203);
insert into Faculty Values('PSS23','Pradeep SHARMA',14, 'M.TECH','CS125',203);
insert into Faculty Values('VMS23','VIKRAM Meena',15, 'Ph.D','CS126');
insert into Faculty  Values('PK23','PRADEEP K',10, 'MBA','CS127',203);



insert into Faculty Values('JK23',' J.KUMAR ',17 ,'Ph.D','IT121',203);
insert into Faculty  Values('GNU23','GOVIND NAGAR UPADHAY' ,8,'MBA','IT122',203 );
insert into Faculty Values('MLP23','M.L.PRASAD',2,'Ph.D','IT123',203);
insert into Faculty Values('RKJ23','R.K. JHA',12,'MBA','IT124',203);
insert into Faculty Values('AK23','ANURUDDHA KUMAR',4, 'M.TECH','IT125',203);
insert into Faculty Values('SG23','SANKALP GOUR',5, 'Ph.D','ITE126',203);
insert into Faculty  Values('RSS23','ROHAN SACHAN',6, 'Ph.D','ITE127',203);




insert into Faculty Values('SKL24','SAIKALA L ',7 ,'Ph.D','CS131',204);
insert into Faculty  Values('MKD24','MANISH KUMAR DHAKAR' ,8,'MBA','CS132',204 );
insert into Faculty Values('SNV24','SAROJ V',9,'Ph.D','CS133',204);
insert into Faculty Values('MBM24','MUKUT C MEENA',10,'MBA','CS134',204);
insert into Faculty Values('SRT24','SMITH RAJPUT',5, 'M.TECH','CS0135',204);
insert into Faculty Values('VIK24','VISWANATHAN IYER K',12, 'Ph.D','CS136',204);
insert into Faculty  Values('WIF24','WILLIUM FREDERICK',12, 'Ph.D','CS137',204);



insert into Faculty Values('KD24','KAUSTUBH DWIVEDI',7 ,'Ph.D','IT131',204);
insert into Faculty  Values('MD24','MANISH DUBEY' ,8,'MBA','IT132',204 );
insert into Faculty Values('HD24','HARSH DWIVEDI',9,'Ph.D','IT133',204);
insert into Faculty Values('SJM24','SHYAM JI ',10,'MBA','IT134',204);
insert into Faculty Values('DK24','DINESH KUMAR',5, 'M.TECH','IT135',204);
insert into Faculty Values('VM24','VIKAS MISHRA',12, 'Ph.D','IT136',204);
insert into Faculty  Values('AS24','ANDREW SIMONS',12, 'Ph.D','IT137',204);



insert into Faculty Values('SG25','SANKALP GOUR',7 ,'Ph.D','CS141',205);
insert into Faculty  Values('MM25','MIKESH MISHRA' ,8,'MBA','CS142',205 );
insert into Faculty Values('LL25','LINDA LAKRI',9,'Ph.D','CS143',205);
insert into Faculty Values('KS25',' KAPIL SAMBA ',10,'MBA','CS144',205);
insert into Faculty Values('MM25','MEHUL MISHRA',5, 'M.TECH','CS145',205);
insert into Faculty Values('VK25','VIKAS KASYAP',12, 'BCA','CS146',205);
insert into Faculty  Values('DD25','DAVID DHAVAN',12, 'Ph.D','CS147',205);





insert into Faculty Values('YY25','YOGI YADAV ',7 ,'Ph.D','IT141',205);
insert into Faculty  Values('DM25','DISHA MISHRA' ,8,'MBA','IT142',205 );
insert into Faculty Values('KC25','KAPIL CHOUDHARY',9,'Ph.D','IT143',205);
insert into Faculty Values('SS25',' SUDHA SAMBA ',10,'MBA','IT144',205);
insert into Faculty Values('PM25','PRIYA MISHRA',5, 'M.TECH','IT145',205);
insert into Faculty Values('MK25','MALIK KHAN',12, 'Ph.D','IT146',205);
insert into Faculty  Values('DK25','DAVID KUMAR',12, 'Ph.D','IT147',205);




insert into Faculty Values('HY26','HARSHA YADAV ',7 ,'Ph.D','CS151',206);
insert into Faculty  Values('KM26','KRITIKA MISHRA' ,8,'MBA','CS152',206 );
insert into Faculty Values('KC26','KUNAL CHOUDHARY',9,'Ph.D','CS153',206);
insert into Faculty Values('SS26',' SAVITA SAMBA ',10,'MBA','CS154',206);
insert into Faculty Values('DM26','DILIP MISHRA',5, 'M.TECH','CS155',206);
insert into Faculty Values('MK26','MOHAMAD KAIF',12, 'Ph.D','CS156',206);
insert into Faculty  Values('ABD26','A.B.DIVILIARS',12, 'MBA','CS157',206);






insert into Faculty Values('AY25','AMAN YADAV ',7 ,'Ph.D','IT151',206);
insert into Faculty  Values('EM25','EKTA MISHRA' ,8,'MBA','IT152',206 );
insert into Faculty Values('JD26','JAGDISH DWIVEDI',9,'Ph.D','IT153',206);
insert into Faculty Values('KD25',' KUSUM DWIVEDI ',10,'MBA','IT154',206);
insert into Faculty Values('DD25',' DIVYA DWIVEDI',5, 'M.TECH','IT155',206);
insert into Faculty Values('ZK25','ZIAUL KHAN',12, 'Ph.D','IT156',206);
insert into Faculty  Values('DM25','DAVID MILLAR',17, 'Ph.D','IT0157',206);









insert into Faculty Values('LS27','LALIT SINGH ',7 ,'Ph.D','CS161',207);
insert into Faculty  Values('FS27','FATIMA SEKH' ,8,'MBA','CS162',207 );
insert into Faculty Values('GN27','GNANA NIVAS',9,'Ph.D','CS163',207);
insert into Faculty Values('JS27',' JIHAD SEKH ',10,'MBA','CS164',207);
insert into Faculty Values('BM27','BHIM MISHRA',5, 'M.TECH','CS165',207);
insert into Faculty Values('LK27','LALIT KAIF',12, 'Ph.D','CS166',207);
insert into Faculty  Values('VK27','VIRAT KOHLI',12, 'Ph.D','CS167',207);





insert into Faculty Values('AK27',' AMIR KHAN',7 ,'Ph.D','IT161',207);
insert into Faculty  Values('HA27','HARSH AWASTHI' ,8,'MBA','IT162',207 );
insert into Faculty Values('SS27','SUNNY SANKESARA',9,'Ph.D','IT163',207);
insert into Faculty Values('JD27',' JONNY DHOOT ',10,'MBA','IT164',207);
insert into Faculty Values('KY27','KRISNA YADAV',5, 'M.TECH','IT165',207);
insert into Faculty Values('GK27','GABRU KAIF',12, 'Ph.D','IT166',207);
insert into Faculty  Values('RP27','RICKT PONTING',12, 'Ph.D','IT167',207);




insert into Faculty Values('DY28','DINESH YADAV ',7 ,'Ph.D','CS171',208);
insert into Faculty  Values('JA28',' JONNY ANDREWS' ,8,'MBA','CS172',208 );
insert into Faculty Values('KC28','KAPIL DEV',9,'Ph.D','CS173',208);
insert into Faculty Values('DS28',' DEVI SRI ',10,'MBA','CS174',208);
insert into Faculty Values('GT28','GARIMA TIWARI',5, 'M.TECH','CS175',208);
insert into Faculty Values('MD28','MAHIMA DEVI',12, 'Ph.D','CS176',208);
insert into Faculty  Values('JDD28','JEETU DUBEY',12, 'Ph.D','CS177',208);




insert into Faculty Values('AK28',' AADIL KHAN',7 ,'Ph.D','IT171',208);
insert into Faculty  Values('HA28','HIMESH AWASTHI' ,8,'MBA','IT172',208 );
insert into Faculty Values('SS28','SUNIL SANKESARA',9,'Ph.D','IT173',208);
insert into Faculty Values('JD28',' JEETU DHOOT ',10,'MBA','IT174',208);
insert into Faculty Values('KY28','KEDAR YADAV',5, 'M.TECH','IT175',208);
insert into Faculty Values('GK28','GEYAN KAIF',12, 'Ph.D','IT176',208);
insert into Faculty  Values('SN28','SUNIL NARAIN',12, 'Ph.D','IT177',208);





insert into Faculty Values('HPY29','HARI PRASAD YADAV ',7 ,'Ph.D','CS181',209);
insert into Faculty  Values('MF29',' M.FARAN ' ,8,'MBA','CS182',209 );
insert into Faculty Values('HK29','HUSSIAN KHAN',9,'Ph.D','CS183',209);
insert into Faculty Values('IS29',' INNAYA SINGH ',10,'MBA','CS184',209);
insert into Faculty Values('LS29','LALITA SEKH',5, 'M.TECH','CS185',209);
insert into Faculty Values('MD29','MAHIMA DUBEY',12, 'Ph.D','CS186',209);
insert into Faculty  Values('JDD29','JOHN DUBEY',12, 'Ph.D','CS187',209);




insert into Faculty Values('AK29',' ANAS KHAN',7 ,'Ph.D','IT181',209);
insert into Faculty  Values('HA29','HARDIK AWASTHI' ,8,'MBA','IT182',209 );
insert into Faculty Values('SS29','SHOBHIT SANKESARA',9,'Ph.D','IT183',209);
insert into Faculty Values('JD29',' JACOB DHOOT ',10,'MBA','IT184',209);
insert into Faculty Values('KY29','KESAV YADAV',5, 'M.TECH','IT185',209);
insert into Faculty Values('NY29','NOBITA YOHANA',12, 'Ph.D','IT186',209);
insert into Faculty  Values('SSN29','SUSHIL S.N',12, 'Ph.D','IT187',209);


insert into Faculty Values('HY20','DINESH YADAV ',7 ,'Ph.D','CS191',210);
insert into Faculty  Values('KS20',' KARAN SINGH' ,8,'MBA','CS192',210 );
insert into Faculty Values('KC20','KAPIL DWIVEDI',9,'Ph.D','CS193',210);
insert into Faculty Values('DS20',' DEVI SRIVASTAV ',10,'MBA','CS194',210);
insert into Faculty Values('GT20','GANESH TIWARI',5, 'M.TECH','CS195',210);
insert into Faculty Values('MD20','MAHIMA DUBAY',12, 'Ph.D','CS196',210);
insert into Faculty  Values('JS20','JACOB SMITH',12, 'Ph.D','CS197',210);




insert into Faculty Values('SK20',' SALMAN KHAN',7 ,'Ph.D','IT191',210);
insert into Faculty  Values('HH20','HIMESH HITKOSHI' ,8,'MBA','IT192',210 );
insert into Faculty Values('SS20','SHASHANK SANKESARA',9,'Ph.D','IT193',210);
insert into Faculty Values('RD20',' ROHAN DHOOT ',10,'MBA','IT194',210);
insert into Faculty Values('KY20','KUNAL YADAV',5, 'M.TECH','IT195',210);
insert into Faculty Values('GS20','GIRISH SINGH',12, 'Ph.D','IT196',210);
insert into Faculty  Values('ST20','SUNIL TIWARI',12, 'Ph.D','IT197',210);
