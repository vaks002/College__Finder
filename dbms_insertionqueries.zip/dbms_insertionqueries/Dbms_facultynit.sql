insert into Faculty Values('MRL11','Mehul Raval',5 ,'Ph.D','CS01',101);
insert into Faculty  Values('MVJ11','M V Joshi' ,8,'MBA','CS02',101 );
insert into Faculty Values('ABJ11','Aseem Benerji',9,'Ph.D','CS04',101);
insert into Faculty Values('PMJ11','P M Jaat',12,'Ph.D','CS03',101);
insert into Faculty Values('VS11','V Sunita',6, 'M.TECH','CS05' ,101);
insert into Faculty Values('SS11','Sanjay Srivastava',11, 'Ph.D','CS06',101);
insert into Faculty  Values('VKC11','Vijay Kumar Chakka',8, 'Ph.D','CS07',101);


insert into Faculty Values('AKV11','ANANDAKRISHNAN V.',13 ,'Ph.D','ME01',101);
insert into Faculty  Values('AG11','ARUNAGIRI.A.' ,8,'MBA','ME03' ,101);
insert into Faculty Values('DLK11','DHANALAKSHMI K',9,'Ph.D','ME02',101);
insert into Faculty Values('DDS11','DEENDAYAL SHARMA',12,'Ph.D','ME04',101);
insert into Faculty Values('GNP11','GOPALAN N.P.',14, 'M.TECH','ME05',101);
insert into Faculty Values('HJ11','HEMALATHA.J.',5, 'Ph.D','ME06',101);
insert into Faculty  Values('IK11','IRFAN KHAN',10, 'MBA','ME07',101);


insert into Faculty Values('DA11','Deepak Atolia ',4 ,'Ph.D','EE01',101);
insert into Faculty  Values('HT11','Hitesh Tilwani' ,7,'MBA','EE03',101 );
insert into Faculty Values('SK11','Sanjay Kumar',6,'Ph.D','EE02',101);
insert into Faculty Values('AV11','Anil Vanjani ',2,'MBA','EE04',101);
insert into Faculty Values('RM11','Rohan Mathur',10, 'M.TECH','EE05',101);
insert into Faculty Values('SBM11','Suraj Bhan Meena',3, 'Ph.D','EE06',101);
insert into Faculty  Values('RVS11','Ravi Kumar Sharma',8, 'MBA','EE07',101);

insert into Faculty Values('HS11',' H.S. SHARMA',3 ,'M.TECH','CE01',101);
insert into Faculty  Values('NK11','N.Kumar' ,8,'MBA','CE03',101 );
insert into Faculty Values('RJS11','R.J. SHARMA',6,'Ph.D','CE02',101);
insert into Faculty Values('PKM11','P.K. MISHRA',11,'Ph.D','CE04',101);
insert into Faculty Values('MSC11','M.S. CHOUHAN',11, 'M.TECH','CE05',101);
insert into Faculty Values('AS11','Ashutosh Sharma',5, 'MBA','CE06',101);
insert into Faculty  Values('AM11','Alok Mittal',7, 'MBA','CE07',101);


insert into Faculty Values('MK11','Manmohan Kapshe ',1 ,'Ph.D','EC01',101);
insert into Faculty  Values('NS11','Namita Srivastava' ,8,'MBA','EC03',101 );
insert into Faculty Values('PKK11','PREMKUMAR K.	',9,'Ph.D','EC02',101);
insert into Faculty Values('MKC11','M.KALICHARAN',12,'MBA','EC04',101);
insert into Faculty Values('PKS11','PREMKUMAR SHARMA',14, 'M.TECH','EC05',101);
insert into Faculty Values('VKS11','VIKRAM SINGH',5, 'Ph.D','EC06',101);
insert into Faculty  Values('PK11','PRADEEP K',10, 'MBA','EC07',101);


insert into Faculty Values('JKN11',' J.K. NARAYANA',7 ,'Ph.D','CHE01',101);
insert into Faculty  Values('GN11','GOVIND NAGAR' ,8,'MBA','CHE02' ,101);
insert into Faculty Values('MLD11','M.L.DAS',9,'Ph.D','CHE03',101);
insert into Faculty Values('RKV11','R.K. VIJAY',12,'MBA','CHE04',101);
insert into Faculty Values('AS11','ANURAG SHARMA',4, 'M.TECH','CHE05',101);
insert into Faculty Values('SG11','SUNIL GOUR',5, 'Ph.D','CHE06',101);
insert into Faculty  Values('RSS11','ROHAN  Srivastava',6, 'Ph.D','CHE07',101);

insert into Faculty Values('SKL11','SAIKALA L ',7 ,'Ph.D','IT01',101);
insert into Faculty  Values('MKD11','MANOJ KUMAR DHAKAR' ,8,'MBA','IT03',101 );
insert into Faculty Values('SNV11','SANKARANARAYANAN V',9,'Ph.D','IT02',101);
insert into Faculty Values('MBM11','MUKUT B MEENA',10,'MBA','IT04',101);
insert into Faculty Values('SRT11','SMITH RAJPUT',5, 'M.TECH','IT05',101);
insert into Faculty Values('VNIK11','VISWANATHAN IYER K',12, 'Ph.D','IT06',101);
insert into Faculty  Values('WFR11','WILSON FREDERICK',13, 'Ph.D','IT07',101);








insert into Faculty Values('VK12','VIKRAM MEENA',5 ,'Ph.D','CS11',102);
insert into Faculty  Values('RD12','ROHAN DHOOT' ,8,'MBA','CS12',102 );
insert into Faculty Values('AB12','Aseem sharma',9,'Ph.D','CS14',102);
insert into Faculty Values('PM12','P M Jaat',12,'Ph.D','CS13',102);
insert into Faculty Values('VSS12','V Sunita Sharma',6, 'M.TECH','CS15' ,102);
insert into Faculty Values('SV12','Sanjay Venka',11, 'Ph.D','CS16',102);
insert into Faculty  Values('VK12','Vijay Kumar ',8, 'Ph.D','CS17',102);


insert into Faculty Values('AN12','ANANDA V.',14 ,'Ph.D','ME11',102);
insert into Faculty  Values('AGS12','ARUNAGIRI SHARMA' ,7,'MBA','ME13' ,102);
insert into Faculty Values('DLK12','DHANALAKSHMI K',10,'Ph.D','ME12',102);
insert into Faculty Values('DD12','DEENDAYAL DHOOT',11,'Ph.D','ME14',102);
insert into Faculty Values('GNP12','GOPALAN  PRAKASH',13, 'M.TECH','ME15',102);
insert into Faculty Values('HJ12','HEMALATHA.J.',6, 'Ph.D','ME16',102);
insert into Faculty  Values('IK12','IRFAN KUMAR',9, 'MBA','ME17',102);


insert into Faculty Values('DH12','Deepak Hooda ',4 ,'Ph.D','EE11',102);
insert into Faculty  Values('HD12','Hitesh dixit' ,7,'MBA','EE13',102);
insert into Faculty Values('SK12','Sanjeev Kumar',6,'Ph.D','EE12',102);
insert into Faculty Values('AV12',' Avakaran Vansh ',2,'MBA','EE14',102);
insert into Faculty Values('RM12','Rohan Mathur',10, 'M.TECH','EE15',102);
insert into Faculty Values('SBM12','Suraj Bhan Meena',3, 'Ph.D','EE16',102);
insert into Faculty  Values('RJ12','Rajat Sharma',8, 'MBA','EE17',102);

insert into Faculty Values('HS12',' H.SAI',3 ,'M.TECH','CE11',102);
insert into Faculty  Values('NK12','N.KAMLESH' ,8,'MBA','CE13',102 );
insert into Faculty Values('RJS','R.J. SHARMA',6,'Ph.D','CE12',102);
insert into Faculty Values('PKM12','P.K. MISHRA',11,'Ph.D','CE14',102);
insert into Faculty Values('MSC12','M.S. CHOUHAN',11, 'M.TECH','CE15',102);
insert into Faculty Values('AS12','Ashutosh Sharma',5, 'MBA','CE16',102);
insert into Faculty  Values('AM12','Alok Mishra',7, 'MBA','CE17',102);


insert into Faculty Values('MK12','MADHAV KHANDELWAL',1 ,'Ph.D','EC11',102);
insert into Faculty  Values('NS12','Namita SHARMA' ,8,'MBA','EC13',102 );
insert into Faculty Values('PK12','PRAKASH K.	',9,'Ph.D','EC12',102);
insert into Faculty Values('VM12','VIKAS MUNDRA',12,'MBA','EC14',102);
insert into Faculty Values('PKS12','PREMKUMAR SHARMA',14, 'M.TECH','EC15',102);
insert into Faculty Values('VKS12','VIKRAM SINGH',5, 'Ph.D','EC16',102);
insert into Faculty  Values('PK12','PRADEEP K',10, 'M.TECH','EC17',102);


insert into Faculty Values('JB12',  ' JIGNESH BHATT',7 ,'Ph.D','CHE11',102);
insert into Faculty  Values('G12','GOVINDA N' ,8,'MBA','CHE12' ,102);
insert into Faculty Values('MKV12','MADHAV V',9,'Ph.D','CHE13',102);
insert into Faculty Values('RKV12','R.K. VANJAINI',12,'MBA','CHE14',102);
insert into Faculty Values('AS12','ASHISH SHARMA',4, 'M.TECH','CHE15',102);
insert into Faculty Values('SG12','SANKALP GOUR',5, 'M.TECH','CHE16',102);
insert into Faculty  Values('SV12','SHANKAR VIJAY',6, 'MBA','CHE17',102);

insert into Faculty Values('SKL12','SHARAD KUMAR ',7 ,'Ph.D','IT11',102);
insert into Faculty  Values('MKD12','MANOJ VAJPAYEE' ,8,'MBA','IT13',102 );
insert into Faculty Values('SNV12','SANYA V',9,'Ph.D','IT12',102);
insert into Faculty Values('MM12','MUKUT MAHESHWARI',10,'MBA','IT14',102);
insert into Faculty Values('SCR12','SMITH CHRISTIAN',5, 'M.TECH','IT15',102);
insert into Faculty Values('VK12','VIVEK  KUMAR',12, 'M.TECH','IT16',102);
insert into Faculty  Values('WFR12','WILSON FREDERICK',11, 'MBA','IT17',102);


	









insert into Faculty values('YJ13','YOGENDER JANGIR',11,'M.TECH','CS21',103);
insert into Faculty values('RJ13','RADHESHYAM JANGID',10,'MBA','CS22',103);
insert into Faculty values('PD13','PRAKHAR DHOOT',4,'PHD','CS23',103);
insert into Faculty values('KS13','KAPIL SHARMA',5,'M.TECH','CS24',103);
insert into Faculty values('VB13','VARUN BAFNA',7,'M.TECH','CS25',103);
insert into Faculty values('RDJ13','RAVINDRA JADEJA',6,'MBA','CS26',103);
insert into Faculty values('TN13','T.NATRAJAN',6,'M.TECH','CS27',103);


insert into Faculty values('SK13','SHAHRUKH KHAN',10,'M.TECH','EE21',103);
insert into Faculty values('KD13','KAUSTUBH DWIVEDI',7,'MBA','EE22',103);
insert into Faculty values('YN13','YOGENDER JAIN',6,'M.TECH','EE23',103);
insert into Faculty values('HJ13','HARSHAL JHANWAR',8,'PH,d','EE24',103);
insert into Faculty values('AN13','ABHISHEK NAGAR',13,'MBA','EE25',103);
insert into Faculty values('NJ13','NAMAN JHANWAR',5,'M.TECH','EE26',103);
insert into Faculty values('KH13','KUMAR HIMANSHU',9,'M.S','EE27',103);


insert into Faculty values('SS13','SANDEEP SANKESARA',10,'M.TECH','EC21',103);
insert into Faculty values('KR13','KAUSTUBH KAPOOR',7,'MBA','EC22',103);
insert into Faculty values('YDJ13','YOGENDER JANGIR',6,'M.TECH','EC23',103);
insert into Faculty values('NAJ13','NAVEEN JHANWAR',8,'PH,d','EC24',103);
insert into Faculty values('ABY13','ABHIYUDAY NAGAR',13,'MBA','EC25',103);
insert into Faculty values('GJ13','GAGAN JHANWAR',5,'M.TECH','EC26',103);
insert into Faculty values('HK13',' HIMANSHU KUMAR',9,'M.S','EC27',103);







insert into Faculty values('SD13','SANDY DIMITRI',10,'M.TECH','IT21',103);
insert into Faculty values('KKD13','KAUSTUBH KUMAR DWIVEDI',7,'MBA','IT22',103);
insert into Faculty values('FJ13','FARAN  JANGIR',6,'M.TECH','IT23',103);
insert into Faculty values('BJ13','BABU JHANWAR',8,'PH,d','IT24',103);
insert into Faculty values('BN13','BHARGAV NAGAR',13,'MBA','IT25',103);
insert into Faculty values('SJ13','SUMAN JHANWAR',5,'M.TECH','IT26',103);
insert into Faculty values('RK13',' RISHABH KUMAR',9,'M.S','IT27',103);



insert into Faculty values('KUY13','KULDEEP YADAV',10,'M.TECH','CHE21',103);
insert into Faculty values('KUS13','KUSH SINGH',7,'MBA','CHE22',103);
insert into Faculty values('NAJ13','NAMAZ  JANGIR',6,'M.TECH','CHE23',103);
insert into Faculty values('BLJ13','BABULAL JHANWAR',8,'PH,d','CHE24',103);
insert into Faculty values('BAN13','BASMATI NAGAR',13,'MBA','CHE25',103);
insert into Faculty values('SUS13','SUMAN  SINGH ',5,'M.TECH','CHE26',103);
insert into Faculty values('HB13',' HARASHA BHOGLE',9,'M.S','CHE27',103);





	insert into Faculty values('POS13','POOJA SINGH',10,'M.TECH','ME21',103);
insert into Faculty values('MOD13','MONIKA DURGA',7,'MBA','ME22',103);
insert into Faculty values('SHS13','SHIKHA SACHAN',6,'M.TECH','ME23',103);
insert into Faculty values('SAS13','SHALU SENGAR',8,'PH,d','ME24',103);
insert into Faculty values('SDY13','SANDYA YADAV',13,'MBA','ME25',103);
insert into Faculty values('SY13','SUMAN YADAV',5,'M.TECH','ME26',103);
insert into Faculty values('DP13',' DISHA PATANI',9,'M.S','ME27',103);




insert into Faculty values('RED13','REKHA DEVI',10,'M.TECH','CE21',103);
insert into Faculty values('MKD13','MONIKA KUMARI DURGA',7,'MBA','CE22',103);
insert into Faculty values('BAC13','BARNALI CHETIA',6,'M.TECH','CE23',103);
insert into Faculty values('AAP13','ASHISH PHOPHALIA',8,'PH,d','CE24',103);
insert into Faculty values('HES13','HEET SANKESARA',13,'MBA','CE25',103);
insert into Faculty values('PAS13','PARUL SHAH',5,'M.TECH','CE26',103);
insert into Faculty values('DIP13',' DIPIKA PADUKONE',9,'M.S','CE27',103);








































insert into Faculty values('YJ14','YOGENDER JANGIR',11,'M.TECH','CS31',104); 
insert into Faculty values('RJ14','RADHESHYAM JANGID',10,'MBA','CS32',104); 
insert into Faculty values('PD14','PRAKHAR DHOOT',4,'PHD','CS33',104); 
insert into Faculty values('KS14','KAPIL SHARMA',5,'M.TECH','CS34',104); 
insert into Faculty values('VBF14','VARUN BAFNA',7,'M.TECH','CS35',104); 
insert into Faculty values('RDJ14','RAVINDRA JADEJA',6,'MBA','CS36',104); 
insert into Faculty values('TN14','T.NATRAJAN',6,'M.TECH','CS37',104); 

  

  

insert into Faculty values('SK14','SHAHRUKH KHAN',10,'M.TECH','EE31',104); 
insert into Faculty values('KD14','KAUSTUBH DWIVEDI',7,'MBA','EE32',104); 
insert into Faculty values('YN14','YOGENDER JAIN',6,'M.TECH','EE33',104); 
insert into Faculty values('HJ14','HARSHAL JHANWAR',8,'PH,d','EE34',104); 
insert into Faculty values('AKN14','ABHISHEK KUMAR NAGAR',14,'MBA','EE35',104); 
insert into Faculty values('SKJ14','SANKALP KUMAR JHANWAR',5,'M.TECH','EE36',104); 
insert into Faculty values('KH14','KUMAR HIMANSHU',9,'M.S','EE37',104); 

  

  

insert into Faculty values('SS14','SANDEEP SANKESARA',10,'M.TECH','EC31',104); 
insert into Faculty values('KR14','KAUSTUBH KAPOOR',7,'MBA','EC32',104); 
insert into Faculty values('YDJ14','YOGENDER JANGIR',6,'M.TECH','EC33',104); 
insert into Faculty values('NAJ14','NAVEEN JHANWAR',8,'PH,d','EC34',104); 
insert into Faculty values('ABYN14','ABHIYUDAY NAGAR',14,'MBA','EC35',104); 
insert into Faculty values('GKJ14','GAGAN KUMAR JHANWAR',5,'M.TECH','EC36',104); 
insert into Faculty values('HKT14',' HIMANSHU KUMAR THAKOR',9,'M.S','EC37',104); 

  

  

  

insert into Faculty values('SD14','SANDY DIMITRI',10,'M.TECH','IT31',104); 
insert into Faculty values('KKD14','KAUSTUBH KUMAR DWIVEDI',7,'MBA','IT32',104); 
insert into Faculty values('FJ14','FARAN  JANGIR',6,'M.TECH','IT33',104); 
insert into Faculty values('BJ14','BABU JHANWAR',8,'PH,d','IT34',104); 
insert into Faculty values('GN14','GOUTAM NAGAR',14,'MBA','IT35',104); 
insert into Faculty values('SJ14','SUMAN JHANWAR',5,'M.TECH','IT36',104); 
insert into Faculty values('RKC14',' RISHABH KUMAR CHOUHAN',9,'M.S','IT37',104); 

  
insert into Faculty values('KUY14','KULDEEP YADAV',10,'M.TECH','CHE31',104); 
insert into Faculty values('KUN14','KUSHI NAGAR',7,'MBA','CHE32',104);
insert into Faculty values('VKB14',' VARNIKA BAFNA',6,'M.TECH','CHE33',104); 
insert into Faculty values('BLJ14','BABULAL JHANWAR',8,'PH,d','CHE34',104); 
insert into Faculty values('BAN14','BASMATI NAGAR',13,'MBA','CHE35',104); 
insert into Faculty values('SVS14','SUMAN  VASHISHTH ',5,'M.TECH','CHE36',104); 
insert into Faculty values('HB14',' HARASHA BHOGLE',9,'M.S','CHE37',104); 



insert into Faculty values('HRS14','HARSHITA SINGH',10,'M.TECH','ME31',104); 
insert into Faculty values('HRD14','HARSHITA DURGA',7,'MBA','ME32',104); 
insert into Faculty values('VNS14','VARNIKA SACHAN',6,'M.TECH','ME33',104); 
insert into Faculty values('SAD14','SHALU DWIVEDI',8,'PH,d','ME34',104); 
insert into Faculty values('SDY14','SANDYA YADAV',14,'MBA','ME35',104); 
insert into Faculty values('AY14','AMAN YADAV',5,'M.TECH','ME36',104); 
insert into Faculty values('AD14',' AMAN DHOOT',9,'M.S','ME37',104); 


  

insert into Faculty values('REDJ14','REKHA DEVI BAJAJ',10,'M.TECH','CE31',104); 
insert into Faculty values('MD14','MONIKA DURGA',7,'MBA','CE32',104); 
insert into Faculty values('BAC14','BARNALI CHETIA',6,'M.TECH','CE33',104); 
insert into Faculty values('AS14','AARZOO SHARMA',8,'PH,d','CE34',104); 
insert into Faculty values('MY14','MOHIT YADAV',14,'MBA','CE35',104); 
insert into Faculty values('PA14','PARUL JANGIR',5,'M.TECH','CE36',104); 
insert into Faculty values('DIN14',' DIPIKA NAGAR',9,'M.S','CE37',104); 



















































insert into Faculty values('RLJ15','RAMLAL JANGIR',11,'M.TECH','CS41',105);  
insert into Faculty values('RJ15','RADHESHYAM JANGID',10,'MBA','CS42',105);  
insert into Faculty values('CD15','CHAMAN DHOOT',4,'PHD','CS43',105);  
insert into Faculty values('KS15','KAPIL SHARMA',5,'M.TECH','CS44',105);  
insert into Faculty values('VKL15','VARUN KOHLI',7,'M.TECH','CS45',105);  
insert into Faculty values('RDJ15','RAVINDRA JADEJA',6,'MBA','CS46',105);  
insert into Faculty values('TN15','T.NATRAJAN',6,'M.TECH','CS47',105);  
  



insert into Faculty values('SK15','SHAHRUKH KHAN',10,'M.TECH','EE41',105);  
insert into Faculty values('KD15','KAUSTUBH DWIVEDI',7,'MBA','EE42',105);  
insert into Faculty values('YN15','YOGENDER JAIN',6,'M.TECH','EE43',105);  
insert into Faculty values('HJ15','HARSHAL JHANWAR',8,'PH,d','EE44',105);  
insert into Faculty values('AKN15','ABHISHEK KUMAR NAGAR',15,'MBA','EE45',105);  
insert into Faculty values('SKJ15','SANKALP KUMAR JHANWAR',5,'M.TECH','EE46',105);  
insert into Faculty values('KH15','KUMAR HIMANSHU',9,'M.S','EE47',105);  

  

   


insert into Faculty values('SS15','SANKALP SHARMA',10,'M.TECH','EC41',105);  
insert into Faculty values('KPR15','KAUSTUBH KAPOOR',7,'MBA','EC42',105);  
insert into Faculty values('YJ15','YOGENDER JANGIR',6,'M.TECH','EC43',105);  
insert into Faculty values('NAJ15','NAVEEN JHANWAR',8,'PH,d','EC44',105);  
insert into Faculty values('ABYN15','ABHIYUDAY NAGAR',15,'MBA','EC45',105);  
insert into Faculty values('CKJ15','CHAMAN KUMAR JHANWAR',5,'M.TECH','EC46',105);  
insert into Faculty values('KT15',' KUNAL THAKOR',9,'M.S','EC47',105);  

  

  

insert into Faculty values('NR15','NIKHIL RATHI',10,'M.TECH','IT41',105);  
insert into Faculty values('KKD15','KAUSTUBH KUMAR DWIVEDI',7,'MBA','IT42',105);  
insert into Faculty values('BTK15',' BHAVESH THAOKR',6,'M.TECH','IT43',105);  
insert into Faculty values('BJ15','BABU JHANWAR',8,'PH,d','IT44',105);  
insert into Faculty values('VN15','VISHNU NAGAR',15,'MBA','IT45',105);  
insert into Faculty values('SJ15','SUMAN JHANWAR',5,'M.TECH','IT46',105);  
insert into Faculty values('RKC15',' ROHAN KUMAR CHOUHAN',9,'M.S','IT47',105);  

  

   

insert into Faculty values('KKY15','KULDEEP KUMAR YADAV',10,'M.TECH','CHE41',105);  
insert into Faculty values('DRAJ15','DIKSHA RAJORA',7,'MBA','CHE42',105); 
insert into Faculty values('VKB15',' VARNIKA BAFNA',6,'M.TECH','CHE43',105);  
insert into Faculty values('JYTM15','JYOTI MEENA',8,'PH,d','CHE44',105);  
insert into Faculty values('VNM15','VAISHANAVI MER',13,'MBA','CHE45',105);  
insert into Faculty values('SVS15','SUMAN  VASHISHTH ',5,'M.TECH','CHE46',105);  
insert into Faculty values('HB15',' HARASHA BHOGLE',9,'M.S','CHE47',105);  

  

  

  

insert into Faculty values('HRS15','HARSHITA SINGH',10,'M.TECH','ME41',105);  
insert into Faculty values('VND15','VARNIKA DURGA',7,'MBA','ME42',105);  
insert into Faculty values('HRSMS15','HARSHITA MEENA',6,'M.TECH','ME43',105);  
insert into Faculty values('SAD15','SHALU DWIVEDI',8,'PH,d','ME44',105);  
insert into Faculty values('SDY15','SANDYA YADAV',15,'MBA','ME45',105);  
insert into Faculty values('AY15','AMAN YADAV',5,'M.TECH','ME46',105);  
insert into Faculty values('AD15',' AMAN DHOOT',9,'M.S','ME47',105);  

  
  

insert into Faculty values('REDJ15','REKHA DEVI BAJAJ',10,'M.TECH','CE41',105);  
insert into Faculty values('MD15','MONIKA DURGA',7,'MBA','CE42',105);  
insert into Faculty values('BAC15','BARNALI CHETIA',6,'M.TECH','CE43',105);  
insert into Faculty values('AS15','AARZOO SHARMA',8,'PH,d','CE44',105);  
insert into Faculty values('MY15','MOHIT YADAV',15,'MBA','CE45',105);  
insert into Faculty values('PA15','PARUL JANGIR',5,'M.TECH','CE46',105);  
insert into Faculty values('DIN15',' DIPIKA NAGAR',9,'M.S','CE47',105);   


























































































